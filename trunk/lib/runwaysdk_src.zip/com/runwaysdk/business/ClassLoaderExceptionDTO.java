package com.runwaysdk.business;

public class ClassLoaderExceptionDTO extends BusinessExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 1812217044054342437L;

  /**
   * Constructs a new ClassLoaderExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public ClassLoaderExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
