package com.runwaysdk.business;

public class UnimplementedStubExceptionDTO extends BusinessExceptionDTO
{
  private static final long serialVersionUID = 1246786909541311143L;

  /**
   * Constructs a new UnimplementedStubExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public UnimplementedStubExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
