package com.runwaysdk.business;

public abstract class LoginExceptionDTO extends BusinessExceptionDTO
{
  /**
   * Constructs a new LoginExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public LoginExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
