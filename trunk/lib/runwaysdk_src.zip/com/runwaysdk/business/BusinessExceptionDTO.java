package com.runwaysdk.business;

import com.runwaysdk.RunwayExceptionDTO;

public class BusinessExceptionDTO extends RunwayExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 4740237099918235214L;

  /**
   * Constructs a new BusinessExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public BusinessExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
