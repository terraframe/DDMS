package com.runwaysdk.business;

public class DeleteTypePermissionExceptionDTO extends BusinessExceptionDTO
{
  /**
   *
   */
  private static final long serialVersionUID = -2687116587654303384L;

  /**
   * Constructs a new DeleteTypePermissionExceptionDTO with the specified localized message from the server.
   *
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public DeleteTypePermissionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
