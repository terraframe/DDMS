package com.runwaysdk.business;

public class InvalidEnumerationNameDTO extends BusinessExceptionDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = 4893715540653107245L;

  /**
   * Thrown when an enumeration name is not valid with respect to the given enumeration.
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public InvalidEnumerationNameDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
