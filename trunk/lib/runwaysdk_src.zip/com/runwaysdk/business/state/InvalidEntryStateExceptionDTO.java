package com.runwaysdk.business.state;

public class InvalidEntryStateExceptionDTO extends StateExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -715297801699719728L;

  /**
   * Constructs a new InvalidEntryStateExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public InvalidEntryStateExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
