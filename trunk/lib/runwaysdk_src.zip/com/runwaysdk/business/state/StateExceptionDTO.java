package com.runwaysdk.business.state;

import com.runwaysdk.business.BusinessExceptionDTO;

public abstract class StateExceptionDTO extends BusinessExceptionDTO
{
  /**
   * Constructs a new StateExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public StateExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
