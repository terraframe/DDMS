package com.runwaysdk.business.state;

public class DefaultStateExistsExceptionDTO extends StateExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 107986762650662717L;

  /**
   * Constructs a new DefaultStateExistsExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public DefaultStateExistsExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
