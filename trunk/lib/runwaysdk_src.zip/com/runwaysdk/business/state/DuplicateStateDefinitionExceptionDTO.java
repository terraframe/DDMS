package com.runwaysdk.business.state;

public class DuplicateStateDefinitionExceptionDTO extends StateExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 2480451461154386758L;

  /**
   * Constructs a new DuplicateStateDefinitionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public DuplicateStateDefinitionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
