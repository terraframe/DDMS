package com.runwaysdk.business.generation;

import com.runwaysdk.business.BusinessExceptionDTO;

public class CompilerExceptionDTO extends BusinessExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 5483731621714198289L;

  /**
   * Constructs a new CompilerExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public CompilerExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
