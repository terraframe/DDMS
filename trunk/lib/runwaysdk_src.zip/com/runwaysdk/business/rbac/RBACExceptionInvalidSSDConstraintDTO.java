package com.runwaysdk.business.rbac;


public class RBACExceptionInvalidSSDConstraintDTO extends RBACExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -4577685587326444717L;

  /**
   * Constructs a new RBACExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RBACExceptionInvalidSSDConstraintDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
