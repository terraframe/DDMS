package com.runwaysdk.business.rbac;

import com.runwaysdk.business.BusinessExceptionDTO;

public abstract class RBACExceptionDTO extends BusinessExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -3283906124559980566L;

  /**
   * Constructs a new RBACExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RBACExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
