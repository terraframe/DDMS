package com.runwaysdk.business.rbac;


public class RBACExceptionInvalidOperationDTO extends RBACExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 3034908772376729951L;

  /**
   * Constructs a new RBACExceptionInvalidOperationDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RBACExceptionInvalidOperationDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
