package com.runwaysdk.business.rbac;


public class RBACExceptionInvalidStateMachineDTO extends RBACExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 5985933390735954857L;

  /**
   * Constructs a new RBACExceptionInvalidStateMachineDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RBACExceptionInvalidStateMachineDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
