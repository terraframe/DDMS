package com.runwaysdk.business.rbac;


public class RBACExceptionInheritanceDTO extends RBACExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -903298021882524886L;

  /**
   * Constructs a new RBACExceptionInheritanceDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RBACExceptionInheritanceDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
