package com.runwaysdk.business.rbac;


public class RBACExceptionSingleActorConflictingRoleDTO extends RBACExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 6403792805432901348L;

  /**
   * Constructs a new RBACExceptionSingleActorConflictingRoleDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RBACExceptionSingleActorConflictingRoleDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
