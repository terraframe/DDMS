package com.runwaysdk.business.rbac;


public class RBACExceptionInvalidSSDCardinalityDTO extends RBACExceptionDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = -3127347457670131761L;

  /**
   * Constructs a new RBACExceptionInvalidSSDCardinalityDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RBACExceptionInvalidSSDCardinalityDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
