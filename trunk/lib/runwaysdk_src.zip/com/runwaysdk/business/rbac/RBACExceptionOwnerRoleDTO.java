package com.runwaysdk.business.rbac;


public class RBACExceptionOwnerRoleDTO extends RBACExceptionDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = 3579684942204377959L;

  /**
   * Constructs a new RBACExceptionOwnerRoleDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RBACExceptionOwnerRoleDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
