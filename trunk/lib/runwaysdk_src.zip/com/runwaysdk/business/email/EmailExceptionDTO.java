package com.runwaysdk.business.email;

import com.runwaysdk.RunwayExceptionDTO;

/**
 * Exception thrown during an error while sending emails.
 */
public class EmailExceptionDTO extends RunwayExceptionDTO 
{

  /**
   * 
   */
  private static final long serialVersionUID = -11636457896114510L;

  /**
   * Constructs a new EmailExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public EmailExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }

}
