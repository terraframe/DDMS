package com.runwaysdk.controller;

import java.util.Locale;

import com.runwaysdk.ApplicationException;
import com.runwaysdk.ClientExceptionMessageLocalizer;

public class UndefinedControllerActionException extends ApplicationException
{
  /**
   * 
   */
  private static final long serialVersionUID = -8940181977092746966L;

  private String action;
  
  public UndefinedControllerActionException(String devMessage, Throwable cause, Locale locale, String action)
  {
    super(locale, devMessage, cause);
    this.action = action;
  }

  public UndefinedControllerActionException(String devMessage, Locale locale, String action)
  {
    super(locale, devMessage);
    this.action = action;
  }

  public UndefinedControllerActionException(Throwable cause, Locale locale, String action)
  {
    super(locale, cause);

    this.action = action;
  }
  
  @Override
  public String getMessage()
  {
    return ClientExceptionMessageLocalizer.undefinedControllerAction(this.getLocale(), action);
  }

}
