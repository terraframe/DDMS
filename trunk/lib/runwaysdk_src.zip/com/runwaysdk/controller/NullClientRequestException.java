package com.runwaysdk.controller;

import java.util.Locale;

import com.runwaysdk.ApplicationException;
import com.runwaysdk.ClientExceptionMessageLocalizer;

public class NullClientRequestException extends ApplicationException
{
  /**
   * 
   */
  private static final long serialVersionUID = 711455113595282669L;
  
  public NullClientRequestException(String devMessage, Throwable cause, Locale locale)
  {
    super(locale, devMessage, cause);
  }

  public NullClientRequestException(String devMessage, Locale locale)
  {
    super(locale, devMessage);
  }

  public NullClientRequestException(Throwable cause, Locale locale)
  {
    super(locale, cause);
  }

  @Override
  public String getMessage()
  {
    return ClientExceptionMessageLocalizer.nullClientRequestException(this.getLocale());
  }

}
