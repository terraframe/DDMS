package com.runwaysdk.controller;

import java.util.Locale;

import com.runwaysdk.CommonExceptionMessageLocalizer;
import com.runwaysdk.business.ComponentDTO;
import com.runwaysdk.transport.metadata.AttributeMdDTO;

public class ReferenceParseProblemDTO extends ParseProblemDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = -8731459123935906085L;
  
  private String type;

  public ReferenceParseProblemDTO(ComponentDTO component, AttributeMdDTO attributeMd, Locale locale, String value, String type)
  {
    super(component, attributeMd, locale, value);
    
    this.type = type;
  }

  public ReferenceParseProblemDTO(String attributeName, Locale locale, String value, String type)
  {
    super(attributeName, locale, value);
    
    this.type = type;
  }

  @Override
  public String getMessage()
  {
    if(this.getValue() != null)
    {
      return CommonExceptionMessageLocalizer.referenceParseException(this.getLocale(), this.getAttributeLabel(), this.getValue(), type);      
    }
    
    return CommonExceptionMessageLocalizer.referenceParseException(this.getLocale(), this.getAttributeLabel(), type);      
  }
}
