package com.runwaysdk.controller;

import java.util.Locale;

import com.runwaysdk.AttributeNotificationDTO;
import com.runwaysdk.business.ComponentDTO;
import com.runwaysdk.business.RunwayProblemDTO;
import com.runwaysdk.transport.metadata.AttributeMdDTO;

public abstract class ParseProblemDTO extends RunwayProblemDTO implements AttributeNotificationDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = 6321049278249059387L;
  
  private String            componentId;
  
  private String            attributeName;

  private String            attributeLabel;
  
  private String            componentType;
  
  private String            componentLabel;
  
  private Locale            locale;
  
  private String            value;
  

  public ParseProblemDTO(ComponentDTO component, AttributeMdDTO attributeMd, Locale locale, String value)
  {
    super(ParseProblemDTO.class.getName(), "");

    this.componentId = component.getId();
    this.componentType = component.getType();
    this.componentLabel = component.getMd().getDisplayLabel();
    
    this.attributeName = attributeMd.getName();
    this.attributeLabel = attributeMd.getDisplayLabel();
    
    this.locale = locale;
    this.value = value;
  }
  
  public ParseProblemDTO(String attributeName, Locale locale, String value)
  {
    super(ParseProblemDTO.class.getName(), "");

    this.componentId = "---";
    this.componentType = "";
    this.componentLabel = "";
    
    this.attributeName = attributeName;
    this.attributeLabel = attributeName;
    
    this.locale = locale;
    this.value = value;
  }
  
  protected Locale getLocale()
  {
    return locale;
  }
  
  protected String getValue()
  {
    return value;
  }

  /**
   * @see com.runwaysdk.AttributeNotificationDTO#getAttributeDisplayLabel()
   */
  public String getAttributeDisplayLabel()
  {
    return attributeLabel;
  }

  /**
   * @see com.runwaysdk.AttributeNotificationDTO#getAttributeName()
   */
  public String getAttributeName()
  {
    return attributeName;
  }

  public String getAttributeLabel()
  {
    return attributeLabel;
  }
  
  /**
   * @see com.runwaysdk.AttributeNotificationDTO#getComponentId()
   */
  public String getComponentId()
  {
    return componentId;
  }

  /**
   * @see com.runwaysdk.AttributeNotificationDTO#getDefiningType()
   */
  public String getDefiningType()
  {
    return componentType;
  }

  /**
   * @see com.runwaysdk.AttributeNotificationDTO#getDefiningTypeDisplayLabel()
   */
  public String getDefiningTypeDisplayLabel()
  {
    return componentLabel;
  }
}
