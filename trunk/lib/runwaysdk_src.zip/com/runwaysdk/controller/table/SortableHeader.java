package com.runwaysdk.controller.table;

import java.io.IOException;

/**
 * Subclass of Header such that the header is a link
 * which results in the table data being sorted by
 * the header attribute.
 * 
 * @author jsmethie
 */
public class SortableHeader extends Header
{  
  
  public SortableHeader()
  {
    super();
  }

  public SortableHeader(boolean populated)
  {
    super(populated);
  }

  /* (non-Javadoc)
   * @see com.runwaysdk.controller.table.Header#accept(com.runwaysdk.controller.table.TableVisitor, int, int)
   */
  public void accept(TableVisitor visitor, int rowspan, int colspan) throws IOException
  {
    visitor.visitSortableHeader(this, rowspan, colspan);
  }

  /**
   * @return The value of the GET 'sortAttribute' parameter
   */
  public String getSortAttribute()
  {
    Column column = this.getColumn();
    ColumnableIF columnable = column.getColumnable();
    String attribute = column.getAttributeName();
    
    if(columnable instanceof StructColumn)
    {
      StructColumn structColumn = ((StructColumn) columnable);
      
      attribute = structColumn.getAttributeName() + "-" + attribute;      
    }
    
    return attribute;
  }
}
