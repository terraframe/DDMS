package com.runwaysdk.controller.table;

import java.io.IOException;

/**
 * Subclass of Entry specific for defining Headers
 * 
 * @author jsmethie
 */
public class Header extends Entry
{

  public Header()
  {
    super();
  }

  public Header(boolean populated)
  {
    super(populated);
  }

  public void accept(TableVisitor visitor, int rowspan, int colspan) throws IOException
  {
    visitor.visitHeader(this, rowspan, colspan);
  }
}
