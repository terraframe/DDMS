package com.runwaysdk.controller.table;


/**
 * Interface indicating that a Column can be added 
 * to its data structure.
 * 
 * @author jsmethie
 */
public interface ColumnableIF
{
  /**
   * Adds a new Column to the Columnable
   * 
   * @param column Column to add.
   */
  public void addColumn(Column column);
}
