package com.runwaysdk.controller.table;

import java.io.IOException;
import java.io.StringWriter;

/**
 * Defines and Entry in a Column.  An Entry can be a Header, Row, or Footer object
 * 
 * @author jsmethie
 */
public class Entry
{
  /**
   * Flag denoting if the Entry has been populated
   */
  private boolean      populated;

  /**
   * Writer used to capture any pre or post html generated when defining this object.
   */
  private StringWriter writer;
  
  /**
   * The Column in which the Entry belongs
   */
  private Column       column;
  
  private String       classes;

  public Entry()
  {
    this(false);
  }

  public Entry(boolean populated)
  {
    this.populated = populated;
    this.writer = new StringWriter();
    this.classes = null;
  }

  public void setColumn(Column column)
  {
    this.column = column;
  }
  
  public Column getColumn()
  {
    return column;
  }
  
  public void setPopulated(boolean populated)
  {
    this.populated = populated;
  }

  public boolean isPopulated()
  {
    return populated;
  }
  
  public String getClasses()
  {
    return classes;
  }

  public void setClasses(String classes)
  {
    this.classes = classes;
  }

  public StringWriter getWriter()
  {
    return writer;
  }

  public void accept(TableVisitor visitor) throws IOException
  {
    visitor.visitEntry(this);
  }
}
