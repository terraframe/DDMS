package com.runwaysdk.controller;

import java.util.Locale;

import com.runwaysdk.CommonExceptionMessageLocalizer;
import com.runwaysdk.business.ComponentDTO;
import com.runwaysdk.transport.metadata.AttributeMdDTO;

public class IntegerParseExceptionDTO extends ParseProblemDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = 493737886173485535L;

  public IntegerParseExceptionDTO(ComponentDTO component, AttributeMdDTO attributeMd, Locale locale, String value)
  {
    super(component, attributeMd, locale, value);
  }

  public IntegerParseExceptionDTO(String attributeName, Locale locale, String value)
  {
    super(attributeName, locale, value);
  }
  
  @Override
  public String getMessage()
  {
    return CommonExceptionMessageLocalizer.integerParseException(this.getLocale(), this.getAttributeLabel(), this.getValue());
  }

}
