package com.runwaysdk.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.runwaysdk.constants.Constants;
import com.runwaysdk.util.Converter;

/**
 * Parses string into Java Primitive Objects
 *
 * @author jsmethie
 */
public class StandardConverter implements Converter
{
  private static Map<String, PluginIF> pluginMap = new ConcurrentHashMap<String, PluginIF>();

  protected Class<?> c;

  public StandardConverter(Class<?> c)
  {
    this.c = c;
  }

  /**
   * @see com.runwaysdk.util.Converter#format(java.lang.Object, java.util.Locale)
   */
  public String format(Object object, Locale locale)
  {
    return object.toString();
  }

  /**
   * @see com.runwaysdk.util.Converter#parse(java.lang.String, java.util.Locale)
   */
  public Object parse(String value, Locale locale)
  {
    if (c.equals(Character.class))
    {
      return new Character(value.charAt(0));
    }
    else if (c.equals(Boolean.class))
    {
      // Ensure the value is 'true' or 'false' before parsing because all string
      // besides 'true' return false instead of throwing an exception
      if (! ( value.equalsIgnoreCase("true") || value.equalsIgnoreCase("false") ))
      {
        throw new StringParseException();
      }

      return new Boolean(Boolean.parseBoolean(value));
    }
    else if (c.equals(Date.class))
    {
      // Value is a standalone date, thus use the format defined by the properties
      try
      {
        // First try a dateTime format
        SimpleDateFormat dateTime = new SimpleDateFormat(Constants.DATETIME_FORMAT, locale);
        return c.cast(dateTime.parse(value));
      }
      catch (ParseException e)
      {
        // Next Try a date format
        try
        {
          SimpleDateFormat date = new SimpleDateFormat(Constants.DATE_FORMAT, locale);

          return c.cast(date.parse(value));
        }
        catch (ParseException e1)
        {
          // Finally try a time format
          SimpleDateFormat time = new SimpleDateFormat(Constants.TIME_FORMAT, locale);

          try
          {
            return c.cast(time.parse(value));
          }
          catch (ParseException e2)
          {
            throw new StringParseException();
          }
        }
      }
    }

    for (PluginIF pluginIF : pluginMap.values())
    {
      Object parsed = pluginIF.parse(c, value, locale);

      if (parsed != null)
      {
        return parsed;
      }
    }

    // All other primitive classes have a String
    // constructor which will parse the String
    try
    {
      return c.getConstructor(String.class).newInstance(value);
    }
    catch (Exception e)
    {
      throw new StringParseException();
    }
  }

  public static void registerPlugin(PluginIF pluginFactory)
  {
    pluginMap.put(pluginFactory.getModuleIdentifier(), pluginFactory);
  }

  public static interface PluginIF
  {
    public String getModuleIdentifier();

    /**
     * @param value
     * @param locale
     * @return
     */
    public Object parse(Class<?> c, String value, Locale locale);
  }

}
