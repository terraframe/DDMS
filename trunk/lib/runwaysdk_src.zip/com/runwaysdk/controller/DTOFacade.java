package com.runwaysdk.controller;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import com.runwaysdk.business.MutableDTO;
import com.runwaysdk.transport.metadata.AttributeMdDTO;
import com.runwaysdk.util.Converter;

public class DTOFacade
{
  private String     accessor;

  private String     rootMethod;

  private MutableDTO mutableDTO;

  private Class<?>   c;

  public DTOFacade(String accessorName, MutableDTO mutableDTO)
  {
    this.mutableDTO = mutableDTO;
    this.c = mutableDTO.getClass();

    this.accessor = accessorName;
    this.rootMethod = accessorName.substring(0, 1).toUpperCase() + accessorName.substring(1);
  }

  public Boolean isWritable()
  {
    try
    {
      String methodName = "is" + rootMethod + "Writable";
      return (Boolean) c.getMethod(methodName).invoke(mutableDTO);
    }
    catch (Exception e)
    {
      return true;
    }
  }

  public AttributeMdDTO getAttributeMdDTO() throws Exception
  {
    try
    {
      // Root name of all the accessor's getters and setters
      String accessorMd = "get" + rootMethod + "Md";

      return (AttributeMdDTO) c.getMethod(accessorMd).invoke(mutableDTO);
    }
    catch (Exception e)
    {
      if (mutableDTO.hasAttribute(this.accessor))
      {
        return mutableDTO.getAttributeMd(this.accessor);
      }
      else
      {
        throw e;
      }
    }
  }

  public Object getValue() throws Exception
  {
    try
    {
      String methodName = "get" + rootMethod;
      return c.getMethod(methodName).invoke(mutableDTO);
    }
    catch (Exception e)
    {
      if (mutableDTO.hasAttribute(this.accessor))
      {
        return mutableDTO.getObjectValue(this.accessor);
      }
      else
      {
        throw e;
      }
    }
  }

  public void setValue(Object value) throws Exception
  {
    try
    {
      String methodName = "set" + rootMethod;
      Class<?> javaType = this.getAttributeMdDTO().getJavaType();

      c.getMethod(methodName, javaType).invoke(mutableDTO, value);
    }
    catch (Exception e)
    {
      if (mutableDTO.hasAttribute(this.accessor))
      {
        mutableDTO.setValue(this.accessor, value);
      }
      else
      {
        throw e;
      }
    }
  }

  public void addAttribute(Object value) throws Exception
  {
    // Get the method to add an enumeration
    try
    {
      String methodName = "add" + rootMethod;
      Class<?> javaType = this.getAttributeMdDTO().getJavaType();
      Method method = c.getMethod(methodName, javaType);

      method.invoke(mutableDTO, value);
    }
    catch (Exception e)
    {
      if (mutableDTO.hasAttribute(this.accessor))
      {
        mutableDTO.addEnumItem(this.accessor, value.toString());
      }
      else
      {
        throw e;
      }
    }
  }

  /**
   * @param mutableDTO
   *          MutableDTO
   * @param accessorName
   *          Name of the accessor of the desired attribute
   * 
   * @return The converter method with the given accessor name
   * @throws NoSuchMethodException
   * @throws InvocationTargetException
   * @throws IllegalAccessException
   * @throws SecurityException
   * @throws IllegalArgumentException
   * 
   * @throws IllegalArgumentException
   * @throws SecurityException
   * @throws IllegalAccessException
   * @throws InvocationTargetException
   * @throws NoSuchMethodException
   */
  public Converter getConverter() throws Exception
  {
    Class<?> c = mutableDTO.getClass();
    String methodName = "get" + rootMethod + "Converter";

    return (Converter) c.getMethod(methodName).invoke(mutableDTO);
  }

  public void clearAttribute() throws Exception
  {
    try
    {
      String methodName = "clear" + rootMethod;

      c.getMethod(methodName).invoke(mutableDTO);
    }
    catch (Exception e)
    {
      if (mutableDTO.hasAttribute(this.accessor))
      {
        mutableDTO.clearEnum(this.accessor);
      }
      else
      {
        throw e;
      }
    }
  }

}
