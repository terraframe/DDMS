package com.runwaysdk.controller;

import java.util.Locale;

import com.runwaysdk.CommonExceptionMessageLocalizer;
import com.runwaysdk.business.ComponentDTO;
import com.runwaysdk.transport.metadata.AttributeMdDTO;

public class CharacterParseProblemDTO extends ParseProblemDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = -8731459123935906085L;

  public CharacterParseProblemDTO(ComponentDTO component, AttributeMdDTO attributeMd, Locale locale, String value)
  {
    super(component, attributeMd, locale, value);
  }

  public CharacterParseProblemDTO(String attributeName, Locale locale, String value)
  {
    super(attributeName, locale, value);
  }

  @Override
  public String getMessage()
  {
    return CommonExceptionMessageLocalizer.characterParseException(this.getLocale(), this.getAttributeLabel(), this.getValue());
  }
}
