package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.JspTag;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.runwaysdk.business.ComponentDTO;
import com.runwaysdk.controller.tag.develop.AttributeAnnotation;
import com.runwaysdk.controller.tag.develop.TagAnnotation;

@TagAnnotation(name = "option", bodyContent = "scriptless", description = "Select option template")
public class OptionTagSupport extends EventTagSupport
{
  /**
   * Specifies that the option should be disabled when it first loads
   */
  private String disabled;

  /**
   * Defines a label to use when using optgroup
   */
  private String label;

  /**
   * Specifies that the option should appear selected (will be displayed first in the list)
   */
  private String selected;

  public OptionTagSupport()
  {
    super();

    disabled = "false";
    selected = "false";
  }

  @AttributeAnnotation(description = "Specifies that the option should be disabled when it first loads")
  public String getDisabled()
  {
    return disabled;
  }

  public void setDisabled(String disabled)
  {
    this.disabled = disabled;
  }

  @AttributeAnnotation(description = "Defines a label to use when using optgroup")
  public String getLabel()
  {
    return label;
  }

  public void setLabel(String label)
  {
    this.label = label;
  }

  @AttributeAnnotation(description = "Specifies that the option should appear selected (will be displayed first in the list)", rtexprvalue=true)
  public String getSelected()
  {
    return selected;
  }

  public void setSelected(String selected)
  {
    this.selected = selected;
  }

  @Override
  public void doTag() throws JspException, IOException
  {
    JspTag parent = SimpleTagSupport.findAncestorWithClass(this, SelectTagSupport.class);
    JspWriter out = this.getJspContext().getOut();

    if (parent != null)
    {
      SelectTagSupport select = (SelectTagSupport) parent;

      // Get the current item in the select collection
      ComponentDTO current = select.getCurrent();

      // Get the name of the attribute on which the value is determined
      String valueAttribute = select.getValueAttribute();

      //set selected=selected if the current value matches the value stored in the DTO
      if(select.getSelectedValues().contains("|"+current.getValue(valueAttribute)+"|"))
      {
          this.setSelected("selected");
      }

      // Write the value of the option
      out.print("<option value=\"" + current.getValue(valueAttribute) + "\"");

      this.writeOptionalParameters(out);

      out.print(">");

      if(this.getJspBody() != null)
      {
        this.getJspBody().invoke(null);
      }

      out.println("</option>");
    }
  }

  protected void writeSelected(JspWriter out) throws IOException
  {
    if (selected.equalsIgnoreCase("selected"))
    {
      out.print(" selected=\"selected\"");
    }
  }

  protected void writeDisabled(JspWriter out) throws IOException
  {
    if (disabled.equalsIgnoreCase("disabled"))
    {
      out.print(" disabled=\"disabled\"");
    }
  }

  protected void writeLabel(JspWriter out) throws IOException
  {
    if (label != null)
    {
      out.print(" label=\"" + label + "\"");
    }
  }

  @Override
  protected void writeOptionalParameters(JspWriter out) throws IOException
  {
    writeSelected(out);

    writeDisabled(out);

    writeLabel(out);

    super.writeOptionalParameters(out);
  }
}
