package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.JspTag;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.runwaysdk.controller.table.Pagination;
import com.runwaysdk.controller.table.Pagination.Page;
import com.runwaysdk.controller.tag.develop.TagAnnotation;

@TagAnnotation(name="page", bodyContent="empty", description="Template for page anchors")
public class PageTagSupport extends SimpleTagSupport
{
  @Override
  public void doTag() throws JspException, IOException
  {
    JspTag tag = SimpleTagSupport.findAncestorWithClass(this, PaginationTagSupport.class);
    
    if(tag != null)
    {
      Page page = ((PaginationTagSupport) tag).getCurrent();
      
      if(!page.getLeftGap() && !page.getRightGap())
      {
        // Print out a text marker which will replaced with the appropriate page number
        // when the pagination data structure is processed
        this.getJspContext().getOut().print(Pagination.PAGE_MARKER);
      }
    }
  }
}
