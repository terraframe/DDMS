package com.runwaysdk.controller.tag;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.JspTag;

import com.runwaysdk.business.MutableDTO;
import com.runwaysdk.controller.tag.develop.AttributeAnnotation;
import com.runwaysdk.controller.tag.develop.TagAnnotation;

/**
 * @author Justin Smethie
 */
@TagAnnotation(name = "select", description = "A select list of items", bodyContent = "scriptless")
public class SelectTagSupport extends ListElementTagSupport
{
  /**
   * Flag indicating if selecting multiple options is allowed.
   */
  private Boolean multiple;

  /**
   * Flag denoting if the option tag is disabled. Value must be disabled
   */
  private String disabled;

  /**
   * Flag indicating if an empty option should be generated.
   */
  private Boolean includeBlank;

  /**
   * Display Label for ALL option, leave null for no ALL option.
   */
  private String allLabel;
  
  private String size;

  private String selectedValues;

  public String getSelectedValues()
  {
    return selectedValues;
  }

  public SelectTagSupport()
  {
    super();

    includeBlank = false;
  }

  @AttributeAnnotation(description = "Flag indicating if selecting multiple options is allowed.")
  public Boolean getMultiple()
  {
    return multiple;
  }

  public void setMultiple(Boolean multiple)
  {
    this.multiple = multiple;
  }

  @AttributeAnnotation(description = "Flag denoting if the option tag is disabled. Value must be disabled")
  public String getDisabled()
  {
    return disabled;
  }

  public void setDisabled(String disabled)
  {
    this.disabled = disabled;
  }

  @AttributeAnnotation(description = "Flag denoting if an empty option should be generated.", rtexprvalue=true)
  public Boolean getIncludeBlank()
  {
    return includeBlank;
  }

  public void setIncludeBlank(Boolean includeBlank)
  {
    this.includeBlank = includeBlank;
  }

  @AttributeAnnotation(description = "Display Label for ALL option, leave null for no ALL option.", rtexprvalue=true)
  public String getAllLabel()
  {
    return allLabel;
  }
  
  @AttributeAnnotation(description = "Sets the size of the select list", rtexprvalue=true)
  public String getSize()
  {
    return size;
  }

  public void setSize(String size)
  {
    this.size = size;
  }

  public void setAllLabel(String allLabel)
  {
    this.allLabel = allLabel;
  }

  private String join(List<String> s, String delimiter) {
      StringBuilder builder = new StringBuilder();
      Iterator<String> iter = s.iterator();

      while (iter.hasNext()) {
          builder.append(iter.next());
          if (iter.hasNext()) {
              builder.append(delimiter);
          }
      }
      return builder.toString();
  }

  @SuppressWarnings("unchecked")
  public void doTag() throws JspException, IOException
  {
    JspWriter out = this.getJspContext().getOut();
    JspTag parent = findAncestorWithClass(this, ComponentMarkerIF.class);
    String name = this.getParam();
    this.selectedValues = "";

    if (parent != null)
    {
      ComponentMarkerIF component = (ComponentMarkerIF) parent;
      name = component.getParam() + "." + this.getParam();
      MutableDTO item = component.getItem();

      try
      {
        //Object object = new DTOFacade(this.getParam(), item).getValue();
        try
        {
            //try to get attrib as an rnum
            this.selectedValues = "|" + join(item.getEnumNames(this.getParam()),"|")+"|";
        }
        catch (Exception e)
        {
            //try again, perhaps the attrib not an enum
            this.selectedValues = "|"+item.getValue(this.getParam())+"|";

        }
      }
      catch(Exception e)
      {
          e.printStackTrace();
      }

    }

    // Write opening select tag
    out.print("<select name=\"" + name + "\"");
    this.writeOptionalParameters(out);
    out.println(">");

    if(includeBlank)
    {
      out.println("<option value=\"\"></option>");
    }

    if(allLabel != null)
    {
      out.println("<option value=\"ALL\">" + allLabel + "</option>");
    }

    // Loop through the children tag for each item in the select list
    super.doTag();

    // Write closing select tag
    out.println("</select>");
  }

  protected void writeOptionalParameters(JspWriter out) throws IOException
  {
    super.writeOptionalParameters(out);
    
    writeSize(out);
    
    writeDisabled(out);

    writeMultiple(out);
  }

  private void writeSize(JspWriter out) throws IOException
  {
    if (size != null)
    {
      out.print("size=\"" + size + "\"");
    }
  }

  private void writeDisabled(JspWriter out) throws IOException
  {
    if (disabled != null)
    {
      out.print("disabled=\"disabled\"");
    }
  }

  private void writeMultiple(JspWriter out) throws IOException
  {
    if (multiple != null)
    {
      out.print("multiple=\"" + multiple + "\"");
    }
  }
}
