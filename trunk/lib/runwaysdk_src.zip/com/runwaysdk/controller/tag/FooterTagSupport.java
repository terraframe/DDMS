package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.JspTag;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.runwaysdk.controller.table.Entry;
import com.runwaysdk.controller.tag.develop.TagAnnotation;

@TagAnnotation(name="footer", bodyContent="scriptless", description="Footer of a column in a table")
public class FooterTagSupport extends SimpleTagSupport
{
  /**
   * Footer data-structure generated when digesting this Footer tag
   */
  private Entry footer;
  
  public FooterTagSupport()
  {
    this.footer = new Entry();
  }
  
  @Override
  public void doTag() throws JspException, IOException
  {
    if(this.getJspBody() != null)
    {
      this.getJspBody().invoke(footer.getWriter());
    }
        
    JspTag column = findAncestorWithClass(this, AttributeColumnTagSupport.class);
    
    if(column != null)
    {
      ((AttributeColumnTagSupport) column).getColumn().setFooter(footer);
    }
  }
}
