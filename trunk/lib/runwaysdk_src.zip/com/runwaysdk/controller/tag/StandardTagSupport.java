package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.runwaysdk.controller.tag.develop.AttributeAnnotation;

public abstract class StandardTagSupport extends SimpleTagSupport
{
  protected String id;

  protected String lang;

  protected String dir;

  protected String classes;

  protected String style;

  protected String title;

  public StandardTagSupport()
  {
    id = null;
    lang = null;
    dir = null;
    classes = null;
    style = null;
    title = null;
  }
  
  @AttributeAnnotation(description = "A unique id for the element")
  public String getId()
  {
    return id;
  }

  public void setId(String id)
  {
    this.id = id;
  }

  @AttributeAnnotation(description = "Sets the language code")
  public String getLang()
  {
    return lang;
  }

  public void setLang(String lang)
  {
    this.lang = lang;
  }

  @AttributeAnnotation(description = "Sets the text direction")
  public String getDir()
  {
    return dir;
  }

  public void setDir(String dir)
  {
    this.dir = dir;
  }

  @AttributeAnnotation(description = "The class of the element")
  public String getClasses()
  {
    return classes;
  }

  public void setClasses(String classes)
  {
    this.classes = classes;
  }

  @AttributeAnnotation(description = "An inline style definition")
  public String getStyle()
  {
    return style;
  }

  public void setStyle(String style)
  {
    this.style = style;
  }

  @AttributeAnnotation(description = "A text to display in a tool tip")
  public String getTitle()
  {
    return title;
  }

  public void setTitle(String title)
  {
    this.title = title;
  }

  protected void writeTitle(JspWriter out) throws IOException
  {
    if (title != null)
    {
      out.print(" title=\"" + title + "\"");
    }
  }

  protected void writeLang(JspWriter out) throws IOException
  {
    if (lang != null)
    {
      out.print(" lang=\"" + lang + "\"");
    }
  }

  protected void writeDir(JspWriter out) throws IOException
  {
    if (dir != null)
    {
      out.print(" dir=\"" + dir + "\"");
    }
  }

  protected void writeClass(JspWriter out) throws IOException
  {
    if (classes != null)
    {
      out.print(" class=\"" + classes + "\"");
    }
  }

  protected void writeId(JspWriter out) throws IOException
  {
    if (id != null)
    {
      out.print(" id=\"" + id + "\"");
    }
  }

  protected void writeStyle(JspWriter out) throws IOException
  {
    if (style != null)
    {
      out.println(" style=\"" + style + "\"");
    }
  }

  protected void writeOptionalParameters(JspWriter out) throws IOException
  {
    writeId(out);

    writeClass(out);

    writeDir(out);

    writeLang(out);

    writeTitle(out);

    writeStyle(out);
  }

}
