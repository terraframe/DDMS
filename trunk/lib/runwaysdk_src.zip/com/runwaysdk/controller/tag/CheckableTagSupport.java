package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspWriter;

import com.runwaysdk.controller.tag.develop.AttributeAnnotation;

public abstract class CheckableTagSupport extends InputElementTagSupport
{
  /**
   * Flag denoting if the option is checked.  Value must be empty or equal to "checked"
   */
  private String checked;

  public CheckableTagSupport()
  {
    checked = "false";
  }

  @AttributeAnnotation(description="Flag denoting if the option is checked.  Value must be empty or equal to \"checked\"", rtexprvalue=true)
  public String getChecked()
  {
    return checked;
  }

  public void setChecked(String checked)
  {
    this.checked = checked;
  }

  protected void writeChecked(JspWriter out) throws IOException
  {
    if(checked.equals("checked"))
    {
      out.print(" checked = \"checked\"");
    }
  }

  @Override
  protected void writeOptionalParameters(JspWriter out) throws IOException
  {
    writeChecked(out);

    super.writeOptionalParameters(out);
  }


}
