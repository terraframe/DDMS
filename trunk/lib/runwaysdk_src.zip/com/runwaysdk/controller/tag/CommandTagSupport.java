package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.jstl.fmt.LocaleSupport;

import com.runwaysdk.controller.tag.develop.AttributeAnnotation;
import com.runwaysdk.controller.tag.develop.TagAnnotation;
import com.runwaysdk.dataaccess.database.IDGenerator;

@TagAnnotation(name="command", bodyContent="empty", description="Input element to submit the form")
public class CommandTagSupport extends ClassTagSupport
{
  /**
   * URL path for the generated post
   */
  private String action;

  /**
   * Name of the generated HTML submit button
   */
  private String name;

  /**
   * The text to display on the submit button
   */
  private String value = "Submit";

  public CommandTagSupport()
  {
    super();

    this.setId(IDGenerator.nextID());
  }

  public void setAction(String action)
  {
    this.action = action;
  }

  @AttributeAnnotation(required=true, description="Action to take when form is submitted")
  public String getAction()
  {
    return action;
  }

  public void setValue(String value)
  {
    this.value = value;
  }

  @AttributeAnnotation(description="The value of the command button")
  public String getValue()
  {
    return LocaleSupport.getLocalizedMessage((PageContext)this.getJspContext(), value);
    //return value;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  @AttributeAnnotation(required=true, description="The name of the command button")
  public String getName()
  {
    return name;
  }

  @Override
  public void doTag() throws JspException, IOException
  {
    JspWriter out = this.getJspContext().getOut();
    FormTagSupport formTag = (FormTagSupport) findAncestorWithClass(this, FormTagSupport.class);

    formTag.addCommand(this);

    out.println("<input type=\"button\" value=\"" + this.getValue() + "\" name=\"" + name + "\"" + this.generateIdAndClass() + "/>");
  }
}
