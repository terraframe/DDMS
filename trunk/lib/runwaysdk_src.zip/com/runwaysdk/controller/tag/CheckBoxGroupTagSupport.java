package com.runwaysdk.controller.tag;

import com.runwaysdk.controller.tag.develop.AttributeAnnotation;
import com.runwaysdk.controller.tag.develop.TagAnnotation;

@TagAnnotation(name="checkboxGroup", bodyContent="scriptless", description="List of checkbox options")
public class CheckBoxGroupTagSupport extends ListTagSupport
{
  /**
   * Name of the accessor from which to retrieve the value
   */
  protected String  valueAttribute;
  
  public CheckBoxGroupTagSupport()
  {
    super();
  }

  @AttributeAnnotation(required=true, description="Name of the accessor of the desired value parameter")
  public String getValueAttribute()
  {
    return valueAttribute;
  }

  public void setValueAttribute(String valueAttribute)
  {
    this.valueAttribute = valueAttribute;
  }
}
