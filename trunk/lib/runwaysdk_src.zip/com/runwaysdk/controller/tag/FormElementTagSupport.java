package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspWriter;

import com.runwaysdk.controller.tag.develop.AttributeAnnotation;

public abstract class FormElementTagSupport extends EventTagSupport
{  
  /**
   * Position in tabbing order
   */
  protected String tabindex;

  /**
   * Accessibility key character
   */
  protected String accesskey;
  
  protected String onfocus;

  protected String onblur;

  protected String onchange;

  public FormElementTagSupport()
  {
    super();
  }
    
  public void setAccesskey(String accesskey)
  {
    this.accesskey = accesskey;
  }

  @AttributeAnnotation(description="Accessibility key character")
  public String getAccesskey()
  {
    return accesskey;
  }

  public void setTabindex(String tabindex)
  {
    this.tabindex = tabindex;
  }

  @AttributeAnnotation(description="Position in tabbing order")
  public String getTabindex()
  {
    return tabindex;
  }
  
  public void setOnblur(String onblur)
  {
    this.onblur = onblur;
  }

  @AttributeAnnotation(description="The element lost the focus")
  public String getOnblur()
  {
    return onblur;
  }

  public void setOnchange(String onchange)
  {
    this.onchange = onchange;
  }

  @AttributeAnnotation(description="The element value was changed")
  public String getOnchange()
  {
    return onchange;
  }

  public void setOnfocus(String onfocus)
  {
    this.onfocus = onfocus;
  }

  @AttributeAnnotation(description="The element got the focus")
  public String getOnfocus()
  {
    return onfocus;
  }

  protected void writeAccessKey(JspWriter out) throws IOException
  {
    if (accesskey != null)
    {
      out.write(" accesskey=\"" + accesskey + "\"");
    }
  }

  protected void writeTabIndex(JspWriter out) throws IOException
  {
    if (tabindex != null)
    {
      out.write(" tabindex=\"" + tabindex + "\"");
    }
  }

  private void writeOnChange(JspWriter out) throws IOException
  {
    if (onchange != null)
    {
      out.write(" onchange=\"" + onchange + "\"");
    }
  }

  protected void writeOnBlur(JspWriter out) throws IOException
  {
    if (onblur != null)
    {
      out.write(" onblur=\"" + onblur + "\"");
    }
  }

  protected void writeOnFocus(JspWriter out) throws IOException
  {
    if (onfocus != null)
    {
      out.write(" onfocus=\"" + onfocus + "\"");
    }
  }

  
  @Override
  protected void writeOptionalParameters(JspWriter out) throws IOException
  {
    writeTabIndex(out);

    writeAccessKey(out);
    
    writeOnFocus(out);

    writeOnBlur(out);

    writeOnChange(out);

    super.writeOptionalParameters(out);
  }
}
