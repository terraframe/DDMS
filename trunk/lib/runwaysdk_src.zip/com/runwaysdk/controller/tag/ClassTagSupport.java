package com.runwaysdk.controller.tag;

import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.runwaysdk.controller.tag.develop.AttributeAnnotation;

public abstract class ClassTagSupport extends SimpleTagSupport
{
  /**
   * The class of the table 
   */
  private String        classes;
  
  /**
   * Unique id of the table
   */
  private String        id = null;

  @AttributeAnnotation(description = "Unique id of the table")
  public String getId()
  {
    return id;
  }
  
  public void setId(String id)
  {
    this.id = id;
  }
  
  @AttributeAnnotation(description = "Class of the table")  
  public String getClasses()
  {
    return classes;
  }

  public void setClasses(String classes)
  {
    this.classes = classes;
  }

  public String generateIdAndClass()
  {
    StringBuffer buffer = new StringBuffer();
    
    if(id != null)
    {
      buffer.append(" id=\"" + id + "\"");
    }
    
    if(classes != null)
    {
      buffer.append(" class=\"" + classes + "\"");
    }
        
    return buffer.toString();
  }
}
