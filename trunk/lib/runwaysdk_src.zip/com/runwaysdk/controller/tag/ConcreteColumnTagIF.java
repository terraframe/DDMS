package com.runwaysdk.controller.tag;

/**
 * Marker indicating that the ColumnTag is not a composite Column
 * 
 * @author jsmethie
 */
public interface ConcreteColumnTagIF extends ColumnTagIF
{

}
