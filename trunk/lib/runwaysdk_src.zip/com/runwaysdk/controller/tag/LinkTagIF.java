package com.runwaysdk.controller.tag;

public interface LinkTagIF
{
  /**
   * Adds a property name-value mapping to a link or context
   * 
   * @param name Name of the property
   * @param value Value of the property
   */
  public void addProperty(String name, String value);
}
