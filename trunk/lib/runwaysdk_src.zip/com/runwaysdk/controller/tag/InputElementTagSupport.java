package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspWriter;

import com.runwaysdk.controller.tag.develop.AttributeAnnotation;

public abstract class InputElementTagSupport extends FormElementTagSupport
{
  private String value;

  private String readonly;

  private String size;

  private String maxlength;

  private String src;

  private String alt;

  private String usemap;

  private String ismap;

  private String accept;
  
  private String onselect;

  private String align;

  private String disabled;
  
  public InputElementTagSupport()
  {
    super();
  }

  public void setValue(String value)
  {
    this.value = value;
  }

  @AttributeAnnotation(rtexprvalue=true, description="The value to be displayed in the input field")
  public String getValue()
  {
    return value;
  }
  
  public void setAccept(String accept)
  {
    this.accept = accept;
  }

  @AttributeAnnotation(description="List of MIME types for file upload")
  public String getAccept()
  {
    return accept;
  }

  public void setAlt(String alt)
  {
    this.alt = alt;
  }

  @AttributeAnnotation(description="Short alternative description")
  public String getAlt()
  {
    return alt;
  }

  public void setIsmap(String ismap)
  {
    this.ismap = ismap;
  }

  @AttributeAnnotation(description="Use server-side image map")
  public String getIsmap()
  {
    return ismap;
  }

  public void setUsemap(String usemap)
  {
    this.usemap = usemap;
  }

  @AttributeAnnotation(description="Use client-side image map")
  public String getUsemap()
  {
    return usemap;
  }

  public void setMaxlength(String maxlength)
  {
    this.maxlength = maxlength;
  }

  @AttributeAnnotation(description="Max chars for text fields")
  public String getMaxlength()
  {
    return maxlength;
  }

  public void setSize(String size)
  {
    this.size = size;
  }

  @AttributeAnnotation(description="Size of the input field")
  public String getSize()
  {
    return size;
  }

  public void setSrc(String src)
  {
    this.src = src;
  }

  @AttributeAnnotation(description="For fields with images")
  public String getSrc()
  {
    return src;
  }

  public void setReadonly(String readonly)
  {
    this.readonly = readonly;
  }

  @AttributeAnnotation(description="Flag indicating if the input is read only")
  public String getReadonly()
  {
    return readonly;
  }  

  @AttributeAnnotation(description="Alignment")
  public String getAlign()
  {
    return align;
  }

  public void setAlign(String align)
  {
    this.align = align;
  }

  @AttributeAnnotation(description="Disabled input controls")
  public String getDisabled()
  {
    return disabled;
  }

  public void setDisabled(String disabled)
  {
    this.disabled = disabled;
  }
  
  public void setOnselect(String onselect)
  {
    this.onselect = onselect;
  }

  @AttributeAnnotation(description="Some text was selected")
  public String getOnselect()
  {
    return onselect;
  }

  protected void writeDisabled(JspWriter out) throws IOException
  {
    if(disabled != null)
    {
      out.print(" disabled=\"" + disabled + "\"");
    }
  }

  protected void writeOnSelect(JspWriter out) throws IOException
  {
    if (onselect != null)
    {
      out.write(" onselect=\"" + onselect + "\"");
    }
  }

  

  protected void writeAccept(JspWriter out) throws IOException
  {
    if (accept != null)
    {
      out.write(" accept=\"" + accept + "\"");
    }
  }


  protected void writeIsMap(JspWriter out) throws IOException
  {
    if (ismap != null)
    {
      out.write(" ismap=\"" + ismap + "\"");
    }
  }

  protected void writeUseMap(JspWriter out) throws IOException
  {
    if (usemap != null)
    {
      out.write(" usemap=\"" + usemap + "\"");
    }
  }

  protected void writeAlt(JspWriter out) throws IOException
  {
    if (alt != null)
    {
      out.write(" alt=\"" + alt + "\"");
    }
  }

  protected void writeSrc(JspWriter out) throws IOException
  {
    if (src != null)
    {
      out.write(" src=\"" + src + "\"");
    }
  }

  protected void writeMaxLength(JspWriter out) throws IOException
  {
    if (maxlength != null)
    {
      out.write(" maxlength=\"" + maxlength + "\"");
    }
  }

  protected void writeSize(JspWriter out) throws IOException
  {
    if (size != null)
    {
      out.write(" size=\"" + size + "\"");
    }
  }

  protected void writeReadOnly(JspWriter out) throws IOException
  {
    if (readonly != null)
    {
      out.write(" readonly=\"" + readonly + "\"");
    }
  }

  
  protected void writeOptionalParameters(JspWriter out) throws IOException
  {
    writeReadOnly(out);

    writeSize(out);

    writeMaxLength(out);

    writeSrc(out);

    writeAlt(out);

    writeUseMap(out);

    writeIsMap(out);

    writeAccept(out);
        
    writeDisabled(out);       
    
    writeOnSelect(out);
    
    super.writeOptionalParameters(out);
  }
}
