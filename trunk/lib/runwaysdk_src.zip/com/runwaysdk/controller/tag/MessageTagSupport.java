package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.JspTag;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.runwaysdk.business.NotificationDTOIF;
import com.runwaysdk.controller.tag.develop.TagAnnotation;

@TagAnnotation(name="message", bodyContent="empty", description="Marker to denote where to display each message")
public class MessageTagSupport extends SimpleTagSupport
{
  @Override
  public void doTag() throws JspException, IOException
  {
    JspTag parent = SimpleTagSupport.findAncestorWithClass(this, MessagesTagSupport.class);
    JspWriter out = this.getJspContext().getOut();

    if (parent != null)
    {
      MessagesTagSupport messages = (MessagesTagSupport) parent;
      NotificationDTOIF current = messages.getCurrent();

      out.println(current.getMessage());
    }
  }
}
