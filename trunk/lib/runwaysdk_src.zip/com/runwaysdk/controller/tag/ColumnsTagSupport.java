package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.runwaysdk.controller.tag.develop.TagAnnotation;

@TagAnnotation(name="columns", bodyContent="scriptless", description="Area to define columns in a table")
public class ColumnsTagSupport extends SimpleTagSupport
{
  @Override
  public void doTag() throws JspException, IOException
  {
    if(this.getJspBody() != null)
    {
      this.getJspBody().invoke(null);
    }
  }
}
