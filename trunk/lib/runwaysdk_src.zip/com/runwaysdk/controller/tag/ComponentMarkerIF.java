package com.runwaysdk.controller.tag;

import com.runwaysdk.business.MutableDTO;

public interface ComponentMarkerIF
{
  /**
   * @return The parameter name of the component
   */
  public String getParam();
  
  /**
   * @return The {@link MutableDTO} component
   */
  public MutableDTO getItem();
}
