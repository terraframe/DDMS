package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.JspTag;

import com.runwaysdk.business.MutableDTO;
import com.runwaysdk.controller.tag.develop.AttributeAnnotation;
import com.runwaysdk.controller.tag.develop.TagAnnotation;

@TagAnnotation(name="textarea", bodyContent = "scriptless", description="Text input tag")
public class TextAreaTagSupport extends InputElementTagSupport
{
  /**
   * Name of the controller parameter or attribute being inputed
   */
  private String param;
  
  /**
   * The number of rows in the text area 
   */
  private Integer rows;
  
  /**
   * The number of columns in the text area
   */
  private Integer columns;

  public void setParam(String param)
  {
    this.param = param;
  }

  @AttributeAnnotation(required=true, description="The name of the controller parameter or attribute")
  public String getParam()
  {
    return param;
  }
  
  public void setCols(Integer columns)
  {
    this.columns = columns;
  }
  
  @AttributeAnnotation(description="Specifies the visible width of a text-area")
  public Integer getCols()
  {
    return columns;
  }
  
  public void setRows(Integer rows)
  {
    this.rows = rows;
  }

  @AttributeAnnotation(description="Specifies the visible number of rows in a text-area")
  public Integer getRows()
  {
    return rows;
  }

  @Override
  public void doTag() throws JspException, IOException
  {
    JspWriter out = this.getJspContext().getOut();
    JspTag parent = findAncestorWithClass(this, ComponentMarkerIF.class);

    String name = this.getParam();
    String displayValue = this.getValue();

    // If the input tag is in the context of a component then
    // load update the parameter name and display value
    if (parent != null)
    {
      ComponentMarkerIF component = (ComponentMarkerIF) parent;
      MutableDTO item = component.getItem();

      name = component.getParam() + "." + this.getParam();

      if (this.getValue() == null)
      {
        displayValue = item.getValue(this.getParam());
      }
    }

    out.write("<textarea name=\"" + name + "\"");

    writeOptionalParameters(out);

    out.write(">\n");
    
    out.write(displayValue);
    
    out.write("</textarea>");
  }
  
  @Override
  protected void writeOptionalParameters(JspWriter out) throws IOException
  {
    if(columns != null)
    {
      out.write(" cols=\"" + columns + "\"");
    }
    if(rows != null)
    {
      out.write(" rows=\"" + rows + "\"");
    }

    super.writeOptionalParameters(out);
  }

}
