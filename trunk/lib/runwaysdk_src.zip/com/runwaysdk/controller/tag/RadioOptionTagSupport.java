package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.JspTag;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.runwaysdk.business.MutableDTO;
import com.runwaysdk.controller.tag.develop.TagAnnotation;

@TagAnnotation(name="radioOption", bodyContent="scriptless", description="Option in a radio group")
public class RadioOptionTagSupport extends CheckableTagSupport
{
  @Override
  public void doTag() throws JspException, IOException
  {
    JspTag parent = SimpleTagSupport.findAncestorWithClass(this, RadioGroupTagSupport.class);
    JspWriter out = this.getJspContext().getOut();

    if (parent != null)
    {
      RadioGroupTagSupport radio = (RadioGroupTagSupport) parent;
      String name = radio.getParam();

      JspTag component = findAncestorWithClass(this, ComponentMarkerIF.class);

      // If the radio option is used in the context of a component then
      // the name of the component must be prefixed to the name of the radio
      // option
      if (component != null)
      {
        name = ((ComponentMarkerIF) component).getParam() + "." + name;
      }

      MutableDTO current = radio.getItem();
      String valueAttribute = radio.getValueAttribute();

      // Write the value of option for the current item in the radio group
      out.print("<input type=\"radio\" name=\"" + name + "\" value=\"" + current.getValue(valueAttribute) + "\"");

      writeOptionalParameters(out);

      out.print(">");

      if(this.getJspBody() != null)
      {
        this.getJspBody().invoke(null);
      }

      out.println("</input>");
    }
  }
}
