package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.JspTag;

import com.runwaysdk.business.ComponentDTOFacade;
import com.runwaysdk.business.MutableDTO;
import com.runwaysdk.constants.MdAttributeBooleanInfo;
import com.runwaysdk.controller.tag.develop.AttributeAnnotation;
import com.runwaysdk.controller.tag.develop.TagAnnotation;
import com.runwaysdk.transport.attributes.AttributeBooleanDTO;

@TagAnnotation(bodyContent = "empty", name = "boolean", description = "Tag denoting a boolean input")
public class BooleanTagSupport extends InputElementTagSupport
{
  /**
   * Name of the controller parameter or attribute being inputed
   */
  private String param;

  private String trueLabel;

  private String falseLabel;
  
  /**
   * Flag indicating if the positive or negative element is being generated 
   */
  private boolean positive;

  public BooleanTagSupport()
  {
    super();

    positive = true;
  }

  public void setParam(String param)
  {
    this.param = param;
  }

  @AttributeAnnotation(required = true, description = "The name of the controller parameter or attribute")
  public String getParam()
  {
    return param;
  }

  @AttributeAnnotation(description = "The display label for the true option", rtexprvalue = true)
  public String getTrueLabel()
  {
    return trueLabel;
  }

  public void setTrueLabel(String trueLabel)
  {
    this.trueLabel = trueLabel;
  }

  @AttributeAnnotation(description = "The display label for the false option", rtexprvalue = true)
  public String getFalseLabel()
  {
    return falseLabel;
  }

  public void setFalseLabel(String falseLabel)
  {
    this.falseLabel = falseLabel;
  }

  protected void writeId(JspWriter out) throws IOException
  {
    if (id != null)
    {
      String postfix = "positive";
      
      if (!positive)
      {
        postfix = "negative";
      }
      
      out.print(" id=\"" + id + "." + postfix + "\"");
    }
  }


  @Override
  public void doTag() throws JspException, IOException
  {
    JspWriter out = this.getJspContext().getOut();
    JspTag parent = findAncestorWithClass(this, ComponentMarkerIF.class);

    String name = this.getParam();
    String value = this.getValue();

    // If the input tag is in the context of a component then
    // load update the parameter name and display value
    if (parent != null)
    {
      ComponentMarkerIF component = (ComponentMarkerIF) parent;
      MutableDTO item = component.getItem();

      name = component.getParam() + "." + this.getParam();

      if (this.getValue() == null)
      {
        value = item.getValue(this.getParam());
      }

      // set label defaults from metadata if no label is found
      try
      {
        AttributeBooleanDTO abDTO = ComponentDTOFacade.getAttributeBooleanDTO(item, this.getParam());
        if (trueLabel == null)
        {
          trueLabel = abDTO.getAttributeMdDTO().getPositiveDisplayLabel();
        }
        if (falseLabel == null)
        {
          falseLabel = abDTO.getAttributeMdDTO().getNegativeDisplayLabel();
        }
      }
      catch (Exception e)
      {
        e.printStackTrace();
      }


    }
    // set label defaults if no label is found
    if (trueLabel == null)
    {
      trueLabel = "true";
    }
    if (falseLabel == null)
    {
      falseLabel = "false";
    }
    
    positive = true;
    
    out.write("<input type=\"radio\" name=\"" + name + "\" value=\"true\"");

    if (value != null && value.equalsIgnoreCase(MdAttributeBooleanInfo.TRUE))
    {
      out.write(" checked=\"checked\"");
    }

    writeOptionalParameters(out);

    out.write(" /> " + this.getTrueLabel() + " ");
    
    positive = false;

    out.write("<input type=\"radio\" name=\"" + name + "\" value=\"false\"");

    if (value == null || value.equalsIgnoreCase(MdAttributeBooleanInfo.FALSE))
    {
      out.write(" checked=\"checked\"");
    }

    writeOptionalParameters(out);

    out.write(" /> " + this.getFalseLabel());
  }
}