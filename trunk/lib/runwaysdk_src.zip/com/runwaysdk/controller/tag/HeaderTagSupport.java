package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.JspTag;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.runwaysdk.controller.table.Entry;
import com.runwaysdk.controller.tag.develop.TagAnnotation;

@TagAnnotation(name="header", bodyContent="scriptless", description="Header of a table column")
public class HeaderTagSupport extends SimpleTagSupport
{
  
  @Override
  public void doTag() throws JspException, IOException
  {
    JspTag column = findAncestorWithClass(this, ColumnTagIF.class);
    
    if(column != null && this.getJspBody() != null)
    {
      ColumnTagIF columnTag = ((ColumnTagIF) column);      
      Entry header = columnTag.getColumn().getHeader();

      if(this.getJspBody() != null)
      {
        this.getJspBody().invoke(header.getWriter());
      }
      
      header.setPopulated(true);
    }    
  }
}
