package com.runwaysdk.controller.tag;

import java.util.List;

import com.runwaysdk.controller.tag.develop.FunctionAnnotation;

public class FunctionSupport
{
  /**
   * Function used to determin if an object is contained in the given list
   * as defined by the contains method of the list.
   * 
   * @param list List to check
   * @param o Object to check for
   * @return
   */
  @FunctionAnnotation
  public static boolean contains(List<?> list, Object o)
  {
    return list.contains(o);
  }
}
