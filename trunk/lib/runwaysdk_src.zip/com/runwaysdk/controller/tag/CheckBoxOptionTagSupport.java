package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.JspTag;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.runwaysdk.business.MutableDTO;
import com.runwaysdk.controller.tag.develop.TagAnnotation;

@TagAnnotation(name="checkboxOption", bodyContent="scriptless", description="Template for a check box option")
public class CheckBoxOptionTagSupport extends CheckableTagSupport
{
  public CheckBoxOptionTagSupport()
  {
    super();
  }
  
  @Override
  public void doTag() throws JspException, IOException
  {
    JspTag parent = SimpleTagSupport.findAncestorWithClass(this, CheckBoxGroupTagSupport.class);
    JspWriter out = this.getJspContext().getOut();

    if (parent != null)
    {
      CheckBoxGroupTagSupport checkbox = (CheckBoxGroupTagSupport) parent;
      String name = checkbox.getParam();

      JspTag component = findAncestorWithClass(this, ComponentMarkerIF.class);

      // If the combo box is used in the context of a component then
      // the generated parameter name needs to prefix the name of the component
      if (component != null)
      {
        name = ((ComponentMarkerIF) component).getParam() + "." + name;
      }

      MutableDTO current = checkbox.getItem();
      String valueAttribute = checkbox.getValueAttribute();

      out.print("<input type=\"checkbox\" name=\"" + name + "\" value=\"" + current.getValue(valueAttribute) + "\"");

      writeOptionalParameters(out);

      out.print(">");

      if(this.getJspBody() != null)
      {
        this.getJspBody().invoke(null);
      }

      out.println("</input>");
    }
  }
}
