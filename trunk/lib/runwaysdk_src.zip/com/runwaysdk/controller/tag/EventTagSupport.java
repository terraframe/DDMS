package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspWriter;

import com.runwaysdk.controller.tag.develop.AttributeAnnotation;

public abstract class EventTagSupport extends StandardTagSupport
{
  protected String onclick     = null;

  protected String ondblclick  = null;

  protected String onmousedown = null;

  protected String onmouseup   = null;

  protected String onmouseover = null;

  protected String onmousemove = null;

  protected String onmouseout  = null;

  protected String onkeypress  = null;

  protected String onkeydown   = null;

  protected String onkeyup     = null;

  public EventTagSupport()
  {
    super();
  }
  
  @AttributeAnnotation(description="What to do on a mouse click")
  public String getOnclick()
  {
    return onclick;
  }

  public void setOnclick(String onclick)
  {
    this.onclick = onclick;
  }

  @AttributeAnnotation(description="What to do on a mouse doubleclick")
  public String getOndblclick()
  {
    return ondblclick;
  }

  public void setOndblclick(String ondblclick)
  {
    this.ondblclick = ondblclick;
  }

  @AttributeAnnotation(description="What to do when mouse button is pressed")
  public String getOnmousedown()
  {
    return onmousedown;
  }

  public void setOnmousedown(String onmousedown)
  {
    this.onmousedown = onmousedown;
  }

  @AttributeAnnotation(description="What to do when mouse button is released")
  public String getOnmouseup()
  {
    return onmouseup;
  }

  public void setOnmouseup(String onmouseup)
  {
    this.onmouseup = onmouseup;
  }

  @AttributeAnnotation(description="What to do when mouse pointer moves over an element")
  public String getOnmouseover()
  {
    return onmouseover;
  }

  public void setOnmouseover(String onmouseover)
  {
    this.onmouseover = onmouseover;
  }

  @AttributeAnnotation(description="What to do when mouse pointer moves")
  public String getOnmousemove()
  {
    return onmousemove;
  }

  public void setOnmousemove(String onmousemove)
  {
    this.onmousemove = onmousemove;
  }

  @AttributeAnnotation(description="What to do when mouse pointer moves out of an element")
  public String getOnmouseout()
  {
    return onmouseout;
  }

  public void setOnmouseout(String onmouseout)
  {
    this.onmouseout = onmouseout;
  }

  @AttributeAnnotation(description="What to do when key is pressed and released")
  public String getOnkeypress()
  {
    return onkeypress;
  }

  public void setOnkeypress(String onkeypress)
  {
    this.onkeypress = onkeypress;
  }

  @AttributeAnnotation(description="What to do when key is pressed")
  public String getOnkeydown()
  {
    return onkeydown;
  }

  public void setOnkeydown(String onkeydown)
  {
    this.onkeydown = onkeydown;
  }

  @AttributeAnnotation(description="What to do when key is released")
  public String getOnkeyup()
  {
    return onkeyup;
  }

  public void setOnkeyup(String onkeyup)
  {
    this.onkeyup = onkeyup;
  }

  protected void writeOnMouseUp(JspWriter out) throws IOException
  {
    if(onmouseup != null)
    {
      out.print(" onmouseup=\"" + onmouseup + "\"");
    }
  }

  protected void writeOnMouseOver(JspWriter out) throws IOException
  {
    if(onmouseover != null)
    {
      out.print(" onmouseover=\"" + onmouseover + "\"");
    }
  }

  protected void writeOnMouseOut(JspWriter out) throws IOException
  {
    if(onmouseout != null)
    {
      out.print(" onmouseout=\"" + onmouseout + "\"");
    }
  }

  protected void writeOnMouseMove(JspWriter out) throws IOException
  {
    if(onmousemove != null)
    {
      out.print(" onmousemove=\"" + onmousemove + "\"");
    }
  }

  protected void writeOnMouseDown(JspWriter out) throws IOException
  {
    if(onmousedown != null)
    {
      out.print(" onmousedown=\"" + onmousedown + "\"");
    }
  }

  protected void writeOnKeyUp(JspWriter out) throws IOException
  {
    if(onkeyup != null)
    {
      out.print(" onkeyup=\"" + onkeyup + "\"");
    }
  }

  protected void writeOnKeyPress(JspWriter out) throws IOException
  {
    if(onkeypress != null)
    {
      out.print(" onkeypress=\"" + onkeypress + "\"");
    }
  }

  protected void writeOnKeyDown(JspWriter out) throws IOException
  {
    if(onkeydown != null)
    {
      out.print(" onkeydown=\"" + onkeydown + "\"");
    }
  }

  protected void writeOnDblClick(JspWriter out) throws IOException
  {
    if(ondblclick != null)
    {
      out.print(" ondblclick=\"" + ondblclick + "\"");
    }
  }

  protected void writeOnClick(JspWriter out) throws IOException
  {
    if(onclick != null)
    {
      out.print(" onclick=\"" + onclick + "\"");
    }
  }

  protected void writeOptionalParameters(JspWriter out) throws IOException
  {
    super.writeOptionalParameters(out);

    writeOnClick(out);             
    
    writeOnDblClick(out);             
    
    writeOnKeyDown(out);             

    writeOnKeyUp(out);             
    
    writeOnKeyPress(out);             
        
    writeOnMouseUp(out);             
    
    writeOnMouseDown(out);             
    
    writeOnMouseMove(out);             
    
    writeOnMouseOut(out);             
    
    writeOnMouseOver(out);           
  }
}
