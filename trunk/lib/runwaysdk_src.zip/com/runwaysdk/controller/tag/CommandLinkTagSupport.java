package com.runwaysdk.controller.tag;

import java.io.IOException;
import java.io.StringWriter;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;

import org.json.JSONException;
import org.json.JSONObject;

import com.runwaysdk.ApplicationException;
import com.runwaysdk.constants.JSON;
import com.runwaysdk.controller.ServletDispatcher;
import com.runwaysdk.controller.tag.develop.AttributeAnnotation;
import com.runwaysdk.controller.tag.develop.TagAnnotation;



@TagAnnotation(name = "commandLink", bodyContent = "scriptless", description = "Input element to submit the form")
public class CommandLinkTagSupport extends CommandTagSupport implements LinkTagIF
{
  /**
   * Text of the link to display
   */
  private String              display;

  /**
   * Property name-value mapping
   */
  private Map<String, String> properties;

  public CommandLinkTagSupport()
  {
    this.properties = new HashMap<String, String>();
  }

  @AttributeAnnotation(required = false, rtexprvalue = true, description = "Text of the link to display")
  public String getDisplay()
  {
    //return LocaleSupport.getLocalizedMessage((PageContext)this.getJspContext(), display);
    return display;
  }

  public void setDisplay(String display)
  {
    this.display = display;
  }

  public void addProperty(String name, String value)
  {
    this.properties.put(name, value);
  }

  public boolean isAsynchronous()
  {
    Object asynchronous = this.getJspContext().findAttribute(ServletDispatcher.IS_ASYNCHRONOUS);

    if (asynchronous != null)
    {
      return (Boolean) asynchronous;
    }

    return false;
  }

  @Override
  public void doTag() throws JspException, IOException
  {
    StringWriter body = new StringWriter();
    if (this.getJspBody() != null)
    {
      this.getJspBody().invoke(body);
    }

    JspWriter out = this.getJspContext().getOut();

    // Build a list of all the property name-value mappings
    Set<String> keySet = properties.keySet();
    String action = this.getAction();

    if (isAsynchronous())
    {
      JSONObject params = new JSONObject();
      for(String key : keySet)
      {
        try
        {
          params.put(key, properties.get(key));
        }
        catch (JSONException e)
        {
          String error = "The key ["+key+" could not be added to the Command Link.";
          throw new ApplicationException(error, e);
        }
      }

      String notifyCall = JSON.createControllerNotifyListenerCall(action);

      out.print("<span "+this.generateIdAndClass()+">"+this.getDisplay()+"</span>");
      out.println("<script type=\"text/javascript\">");
      out.println("(function(){ ");
      out.println("  document.getElementById('"+this.getId()+"').onclick = function(){");
      out.println("    var params = "+params.toString()+";");
      out.println("    "+notifyCall+"(params, '"+action+"', '"+this.getId()+"');");
      out.println("  };");
      out.println("})();");
      out.println("</script>");
    }
    else
    {
      StringBuffer buffer = new StringBuffer();

      // Seperate each mapping with the '&' character
      for (String key : keySet)
      {
        String encoded = URLEncoder.encode(properties.get(key), "UTF-8");
        buffer.append("&" + key + "=" + encoded);
      }

      out.print("<a href=\"" + action);

      // Replace the first '&' with '?' to make a valid link
      if (keySet.size() > 0)
      {
        out.println("?" + buffer.toString().replaceFirst("&", ""));
      }
      
      String display = (this.getDisplay() == null) ? body.toString() : this.getDisplay();      
      
      out.println("\"" + this.generateIdAndClass() + ">" +  display + "</a>");
    }
  }

}
