package com.runwaysdk.controller.tag;

import com.runwaysdk.controller.tag.develop.AttributeAnnotation;
import com.runwaysdk.controller.tag.develop.TagAnnotation;

@TagAnnotation(name="radioGroup", bodyContent="scriptless", description="List of radio options")
public class RadioGroupTagSupport extends ListTagSupport
{
  /**
   * Name of the accessor from which to retrieve the value
   */
  protected String  valueAttribute;
  
  public RadioGroupTagSupport()
  {
    super();
  }
  
  @AttributeAnnotation(required=true, description="Name of the accessor of the desired value parameter")
  public String getValueAttribute()
  {
    return valueAttribute;
  }

  public void setValueAttribute(String valueAttribute)
  {
    this.valueAttribute = valueAttribute;
  }

}
