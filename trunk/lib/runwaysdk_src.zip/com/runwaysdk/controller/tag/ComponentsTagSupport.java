package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.jstl.core.LoopTagStatus;

import com.runwaysdk.business.MutableDTO;
import com.runwaysdk.controller.tag.develop.AttributeAnnotation;
import com.runwaysdk.controller.tag.develop.TagAnnotation;

@TagAnnotation(name="components", bodyContent="scriptless", description="Array of components")
public class ComponentsTagSupport extends ListTagSupport implements ComponentMarkerIF
{
  public void setParam(String param)
  {
    this.param = param;
  }

  @AttributeAnnotation(required=true, description="The name of the servlet parameter")
  public String getParam()
  {
    LoopTagStatus stat = this.getLoopStatus();
    int c = stat.getCount() - 1;

    return param + "_" + c;
  }

  @Override
  protected void invokeBody() throws JspException, IOException
  {
    JspWriter out = this.getJspContext().getOut();

    LoopTagStatus stat = this.getLoopStatus();
    MutableDTO item = (MutableDTO) stat.getCurrent();

    ComponentTagSupport.doComponent(out, this.getParam(), item);

    if(this.getJspBody() != null)
    {
      this.getJspBody().invoke(null);
    }
  }
}
