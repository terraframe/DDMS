package com.runwaysdk.controller.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.JspTag;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import com.runwaysdk.controller.tag.develop.AttributeAnnotation;
import com.runwaysdk.controller.tag.develop.TagAnnotation;

@TagAnnotation(name="property", bodyContent="empty", description="Parameter name and value pairing")
public class PropertyTagSupport extends SimpleTagSupport
{
  /**
   * Name of the property
   */
  private String name;
  
  /**
   * Value of the property
   */
  private String value;
  
  public PropertyTagSupport()
  {
    this.name = null;
    this.value = null;
  }

  @AttributeAnnotation(required=true, description="Name of the property")
  public String getName()
  {
    return name;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  @AttributeAnnotation(required=true, rtexprvalue=true, description="Value of the property")
  public String getValue()
  {
    return value;
  }

  public void setValue(String value)
  {
    this.value = value;
  }
  
   @Override
  public void doTag() throws JspException, IOException
  {
     JspTag parent = SimpleTagSupport.findAncestorWithClass(this, LinkTagIF.class);
     
     if(parent != null)
     {
       ((LinkTagIF) parent).addProperty(name, value);
     }
  }
}
