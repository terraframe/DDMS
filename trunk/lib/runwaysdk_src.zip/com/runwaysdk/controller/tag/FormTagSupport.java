package com.runwaysdk.controller.tag;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;

import com.runwaysdk.constants.JSON;
import com.runwaysdk.controller.ServletDispatcher;
import com.runwaysdk.controller.tag.develop.AttributeAnnotation;
import com.runwaysdk.controller.tag.develop.TagAnnotation;
import com.runwaysdk.dataaccess.database.IDGenerator;

@TagAnnotation(name = "form", bodyContent = "scriptless", description = "Runway form tag")
public class FormTagSupport extends EventTagSupport
{
  /**
   * 
   */
  private static final long       serialVersionUID = -721616030112375716L;

  /**
   * List of Commands used by this form
   */
  private List<CommandTagSupport> commands         = new LinkedList<CommandTagSupport>();

  /**
   * Form method
   */
  private String                  method;

  /**
   * Form name
   */
  private String                  name;

  private String                  target;

  private String                  onsubmit;

  private String                  onreset;

  public FormTagSupport()
  {
    this.id = IDGenerator.nextID();
    this.commands = new LinkedList<CommandTagSupport>();
    this.method = "GET";
    this.name = null;
    this.target = null;
    this.onsubmit = null;
    this.onreset = null;
  }

  public void setMethod(String method)
  {
    this.method = method;
  }

  @AttributeAnnotation(description = "The HTTP method for sending data to the action URL. Default is get.")
  public String getMethod()
  {
    return method;
  }

  public void setName(String name)
  {
    this.name = name;
  }

  @AttributeAnnotation(required = true, description = "Defines a unique name for the form")
  public String getName()
  {
    return name;
  }

  public void setOnreset(String onreset)
  {
    this.onreset = onreset;
  }

  @AttributeAnnotation(description = "Script to be run when the form is reset")
  public String getOnreset()
  {
    return onreset;
  }

  public void setOnsubmit(String onsubmit)
  {
    this.onsubmit = onsubmit;
  }

  @AttributeAnnotation(description = "Script to be run when the form is submitted")
  public String getOnsubmit()
  {
    return onsubmit;
  }

  public void setTarget(String target)
  {
    this.target = target;
  }

  @AttributeAnnotation(description = "Where to open the target URL")
  public String getTarget()
  {
    return target;
  }

  void addCommand(CommandTagSupport tag)
  {
    this.commands.add(tag);
  }

  @Override
  public void doTag() throws JspException, IOException
  {
    JspWriter out = this.getJspContext().getOut();

    try
    {
      openFormTag(out);

      if(this.getJspBody() != null)
      {
        this.getJspBody().invoke(null);
      }

      closeFormTag(out);
    }
    catch (Exception e)
    {
      // FIXME
      e.printStackTrace();
    }
  }

  private void openFormTag(JspWriter out) throws IOException
  {
    out.print("<form method=\"" + method + "\"");
    out.print(" action=\"\"");
    out.print(" name=\"" + name + "\"");

    this.writeOptionalParameters(out);

    out.print(" >\n");
  }

  @Override
  protected void writeOptionalParameters(JspWriter out) throws IOException
  {
    if (onreset != null)
    {
      out.print(" onrest=\"" + onreset + "\"");
    }

    if (onsubmit != null)
    {
      out.print(" onsubmit=\"" + onsubmit + "\"");
    }

    if (target != null)
    {
      out.print(" target=\"" + target + "\"");
    }

    super.writeOptionalParameters(out);
  }

  public boolean isAsynchronous()
  {
    Object asynchronous = this.getJspContext().findAttribute(ServletDispatcher.IS_ASYNCHRONOUS);

    if (asynchronous != null)
    {
      return (Boolean) asynchronous;
    }

    return false;
  }
  
  private void closeFormTag(JspWriter out) throws IOException
  {
    out.print("</form>");

    out.println();
    out.println("<script type=\"text/javascript\">");
    out.println("(function(){ ");

    for (CommandTagSupport command : commands)
    {
      out.println("// " + command.getAction());
      out.println("document.getElementById(\"" + command.getId() + "\").onclick = function(){");
      if (isAsynchronous())
      {
        String notifyCall = JSON.createControllerNotifyListenerCall(command.getAction());
        
        out.println("  var params = "+JSON.RUNWAY_COLLECT_FORM_VALUES.getLabel()+"('"+this.getId()+"');");
        out.println("  "+notifyCall+"(params, '"+command.getAction()+"', '"+command.getId()+"');");
      }
      else
      {
        out.println("  var formEl = document.getElementById(\"" + this.getId() + "\");");
        out.println("  formEl.action = \"" + command.getAction() + "\";");
        
        String _onsubmit = this.getOnsubmit();
        if(_onsubmit != null && !_onsubmit.equals(""))
        {
          out.println("  formEl.onsubmit();");          
        }
        
        out.println("  var evt = document.createEvent(\"HTMLEvents\");");
        out.println("  evt.initEvent(\"submit\", false, true);");
        out.println("  formEl.dispatchEvent(evt);");
        out.println();
      }
      out.println("};");
    }

    out.println("})();");
    out.println("</script>");
  }
}
