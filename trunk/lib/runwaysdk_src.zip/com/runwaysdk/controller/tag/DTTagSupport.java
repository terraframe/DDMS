package com.runwaysdk.controller.tag;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.JspTag;

import com.runwaysdk.business.MutableDTO;
import com.runwaysdk.controller.DTOFacade;
import com.runwaysdk.controller.tag.develop.AttributeAnnotation;
import com.runwaysdk.controller.tag.develop.TagAnnotation;
import com.runwaysdk.transport.metadata.AttributeMdDTO;

/**
 * @author Darrell Taylor
 */
@TagAnnotation(name = "dt", description = "a DT DL pair with inner tags going in to the DL ", bodyContent = "scriptless")
public class DTTagSupport extends FormElementTagSupport
{

  /**
   * Name of the controller parameter or attribute being inputed
   */
  private String  attribute;

  /**
   * The type of the input field
   */
  private String  type;

  /**
   * The display label for this attribute
   */
  private String  displayLabel;

  /**
   * Flag indicating if a messages tag should generated.
   */
  private Boolean includeMessages;

  public DTTagSupport()
  {
    super();
  }

  public void setAttribute(String attribute)
  {
    this.attribute = attribute;
  }

  @AttributeAnnotation(required = true, description = "The name of the controller parameter or attribute")
  public String getAttribute()
  {
    return attribute;
  }

  public void setType(String type)
  {
    this.type = type;
  }

  @AttributeAnnotation(required = false, description = "The type of the input field")
  public String getType()
  {
    return type;
  }

  @AttributeAnnotation(required = false, description = "The display label for this attribute")
  public String getDisplayLabel()
  {
    return displayLabel;
  }

  public void setDisplayLabel(String displayLabel)
  {
    this.displayLabel = displayLabel;
  }

  @AttributeAnnotation(description = "Flag denoting if an empty option should be generated.", rtexprvalue = true)
  public Boolean getIncludeMessages()
  {
    return includeMessages;
  }

  public void setIncludeMessages(Boolean includeMessages)
  {
    this.includeMessages = includeMessages;
  }

  public void doTag() throws JspException, IOException
  {
    JspWriter out = this.getJspContext().getOut();
    JspTag parent = findAncestorWithClass(this, ComponentMarkerIF.class);

    String name = this.getAttribute();
    String displayLabel = this.getDisplayLabel();
    String description = "";
    String required = "";

    // If the input tag is in the context of a component then
    // load update the parameter name and display value
    if (parent != null)
    {
      ComponentMarkerIF component = (ComponentMarkerIF) parent;
      MutableDTO item = component.getItem();

      name = component.getParam() + "." + this.getAttribute();

      DTOFacade facade = new DTOFacade(this.getAttribute(), item);
      
      if (this.getDisplayLabel() == null)
      {
        try
        {
          AttributeMdDTO attributeMdDTO = facade.getAttributeMdDTO();
          displayLabel = attributeMdDTO.getDisplayLabel();
        }
        catch (Exception e)
        {
          // e.printStackTrace();
          displayLabel = name;
        }
      }
      if (this.getTitle() == null)
      {
        try
        {
          AttributeMdDTO attributeMdDTO = facade.getAttributeMdDTO();
          
          if (attributeMdDTO.isRequired())
          {
            required = "*";
          }

        }
        catch (Exception e)
        {
          // e.printStackTrace();
        }

        try
        {
          AttributeMdDTO attributeMdDTO = facade.getAttributeMdDTO();

          description = attributeMdDTO.getDescription();
          
          String classLabel = item.getMd().getDisplayLabel();
          String attributeLabel = attributeMdDTO.getDisplayLabel();
          
          description += " (" + classLabel + " : " + attributeLabel + ")";
        }
        catch (Exception e)
        {
          // e.printStackTrace();
        }

      }

      try
      {
        if (item.isReadable(this.getAttribute()))
        {
          out.write("<dt ");
          // we want to use classes as an attrib for the inner input
          // tag if it exists
          String inner_class = this.getClasses();
          if (this.getType() != null)
          {
            this.setClasses(null);
          }
          writeOptionalParameters(out);

          out.write(" ><label ");
          if (description.length() + required.length() > 0)
          {
            out.write("title=\"" + required + " " + description + "\"");
          }
          out.write(">");

          if (displayLabel != null)
          {
            out.write(displayLabel);
          }
          out.write("</label></dt>");
          out.write("<dd>");

          // if type is set we write an input tag
          if (this.getType() == "text")
          {

            InputTagSupport it = new InputTagSupport();
            it.setJspContext(this.getJspContext());
            it.setValue(item.getValue(this.getAttribute()));
            it.setParam(name);
            it.setType(this.getType());
            it.setId(this.getAttribute() + "input");
            it.setClasses(inner_class);
            it.doTag();

          }
          // execute any inner tags
          if (this.getJspBody() != null)
          {
            StringWriter body = new StringWriter();
            this.getJspBody().invoke(body);

            if (body.toString().trim().length() > 0)
            {
              out.println(body);
            }
            else
            {
              out.println("-");
            }
          }
          // dt tag always prints out messages
          MessagesTagSupport mt = new MessagesTagSupport();
          mt.setJspContext(this.getJspContext());
          mt.setParent(parent);
          mt.setAttribute(this.getAttribute());
          mt.doTag();

          out.write("</dd>");
        }
      }
      catch (ClassCastException e)
      {
        // something went wrong, do nothing
        e.printStackTrace();
      }
    }

  }

  protected void writeOptionalParameters(JspWriter out) throws IOException
  {
    super.writeOptionalParameters(out);

  }

}
