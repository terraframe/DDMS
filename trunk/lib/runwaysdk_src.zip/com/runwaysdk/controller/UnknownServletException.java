package com.runwaysdk.controller;

import java.util.Locale;

import com.runwaysdk.ClientExceptionMessageLocalizer;
import com.runwaysdk.RunwayExceptionDTO;

public class UnknownServletException extends RunwayExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -1962819927380684052L;

  private Locale locale;
  
  private String controller;
  
  public UnknownServletException(String developerMessage, Locale locale, String controller)
  {
    super(UnknownServletException.class.getName(), "", developerMessage);
    this.controller = controller;
    this.locale = locale;
  }
  
  protected Locale getLocale()
  {
    return this.locale;
  }
  
  @Override
  public String getMessage()
  {
    return ClientExceptionMessageLocalizer.unknownServletException(this.getLocale(), controller);
  }

}
