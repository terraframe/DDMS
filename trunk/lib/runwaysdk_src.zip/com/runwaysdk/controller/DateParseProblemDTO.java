package com.runwaysdk.controller;

import java.util.Locale;

import com.runwaysdk.CommonExceptionMessageLocalizer;
import com.runwaysdk.business.ComponentDTO;
import com.runwaysdk.transport.metadata.AttributeMdDTO;

public class DateParseProblemDTO extends MomentParseExceptionDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = -7199611784136948526L;

  public DateParseProblemDTO(ComponentDTO component, AttributeMdDTO attributeMd, Locale locale, String value, String format)
  {
    super(component, attributeMd, locale, value, format);
  }

  public DateParseProblemDTO(String attributeName, Locale locale, String value, String format)
  {
    super(attributeName, locale, value, format);
  }
  
  @Override
  public String getMessage()
  {
    return CommonExceptionMessageLocalizer.dateParseException(this.getLocale(), this.getAttributeLabel(), this.getValue(), this.getFormat());
  }

}
