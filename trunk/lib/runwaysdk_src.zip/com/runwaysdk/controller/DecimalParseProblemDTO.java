package com.runwaysdk.controller;

import java.util.Locale;

import com.runwaysdk.CommonExceptionMessageLocalizer;
import com.runwaysdk.business.ComponentDTO;
import com.runwaysdk.transport.metadata.AttributeMdDTO;

public class DecimalParseProblemDTO extends ParseProblemDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 2057001161276886831L;

  public DecimalParseProblemDTO(ComponentDTO component, AttributeMdDTO attributeMd, Locale locale, String value)
  {
    super(component, attributeMd, locale, value);
  }

  public DecimalParseProblemDTO(String attributeName, Locale locale, String value)
  {
    super(attributeName, locale, value);
  }
  
  @Override
  public String getMessage()
  {
    return CommonExceptionMessageLocalizer.decimalParseException(this.getLocale(), this.getAttributeLabel(), this.getValue());
  }
}
