package com.runwaysdk.controller;

import java.util.Locale;

import com.runwaysdk.ClientExceptionMessageLocalizer;
import com.runwaysdk.RunwayExceptionDTO;

public class IllegalURIMethodException extends RunwayExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -1962819927380684052L;

  private Locale locale;
  
  private String uri;
  
  public IllegalURIMethodException(String developerMessage, Locale locale, String uri)
  {
    super(IllegalURIMethodException.class.getName(), "", developerMessage);
    this.uri = uri;
    this.locale = locale;
  }
 
  public Locale getLocale()
  {
    return this.locale;
  }
  
  @Override
  public String getMessage()
  {
    return ClientExceptionMessageLocalizer.illegalURIMethodException(this.getLocale(), uri);
  }
}
