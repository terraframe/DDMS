package com.runwaysdk.controller;

public class StringParseException extends RuntimeException
{

  /**
   * 
   */
  private static final long serialVersionUID = 307389657926209506L;

}
