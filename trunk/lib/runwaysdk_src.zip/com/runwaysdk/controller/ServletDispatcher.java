package com.runwaysdk.controller;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONException;

import com.runwaysdk.ApplicationException;
import com.runwaysdk.business.generation.GenerationUtil;
import com.runwaysdk.constants.Constants;
import com.runwaysdk.controller.ActionParameters;
import com.runwaysdk.generation.loader.LoaderDecorator;

public class ServletDispatcher extends HttpServlet
{
  private enum ServletMethod
  {
    GET, POST
  }
  
  public static final String IS_ASYNCHRONOUS = Constants.ROOT_PACKAGE+".isAsynchronous_mojax";
  
  /**
   * Request key whose value is a JSON object representing an Ajax call with complex
   * objects from a controller being invoked directly.
   */
  public static final String MOJAX_OBJECT = Constants.ROOT_PACKAGE+".mojaxObject";
  
  /**
   * 
   */
  private static final long serialVersionUID = -5069320031139205183L;
  
  private Boolean isAsynchronous;
  
  public ServletDispatcher()
  {
    this(false);
  }
  
  public ServletDispatcher(boolean isAsynchronous)
  {
    this.isAsynchronous = isAsynchronous;    
  }

  @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException,
      IOException
  {
    checkAndDispatch(req, resp, ServletMethod.POST);
  }

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException,
      IOException
  {
    checkAndDispatch(req, resp, ServletMethod.GET);
  }

  /**
   * Loads objects from the parameter mapping and executes the given action. If
   * a parsing failure occurs when the objects are loaded then the proper
   * failure action is invoked.
   * 
   * @param req
   *            HttpServletRequest
   * @param resp
   *            HttpServletResponse
   * @param manager
   *            RequestManager manages the status of the parse
   * @param actionName
   *            The name of the action
   * @param controllerName
   *            The name of the controller
   * @param baseClass
   *            The controller base class
   * @param baseMethod
   *            The controller base method
   * 
   * @throws NoSuchMethodException
   * @throws InstantiationException
   * @throws IllegalAccessException
   * @throws InvocationTargetException
   * @throws InstantiationException
   * @throws InvocationTargetException
   */
  @SuppressWarnings("unchecked")
  private void dispatch(HttpServletRequest req, HttpServletResponse resp, RequestManager manager,
      String actionName, String controllerName, Class<?> baseClass, Method baseMethod)
      throws SecurityException, NoSuchMethodException, IllegalArgumentException, IllegalAccessException,
      InstantiationException, InvocationTargetException
  {
    Class<?> controllerClass = LoaderDecorator.load(controllerName);

    Constructor<?> constructor = controllerClass.getConstructor(HttpServletRequest.class, HttpServletResponse.class, Boolean.class);
    Object controller = constructor.newInstance(req, resp, isAsynchronous);
    
    // Add an asynchronous flag to the request object
    req.setAttribute(IS_ASYNCHRONOUS, new Boolean(isAsynchronous));

    // Get parameter information for the base method annotation
    ActionParameters annotation = baseMethod.getAnnotation(ActionParameters.class);
    
    // parameter map will be different depending on the call
    Map<String, String[]> parameters;
    String mojaxObject = req.getParameter(MOJAX_OBJECT);
    if(mojaxObject != null)
    {
        try
        {
          parameters = new MojaxObjectParser(annotation, mojaxObject).getMap();
        }
        catch (JSONException e)
        {
          throw new ApplicationException(e);
        }
    }
    else
    {
      parameters = req.getParameterMap();
    }
    
    Object[] objects = new DispatchUtil(annotation, manager, parameters).getObjects();

    // Ensure an exception has not occured while converting the request
    // parameters to objects. If an exception did occur then invoke the failure
    // case
    if (manager.hasExceptions())
    {
      // FIXME handle case for ajax calls
      dispatchFailure(actionName, baseClass, controllerClass, controller, objects);
    }
    else
    {
      // No problems when converting parameters to objects
      dispatchSuccess(actionName, baseMethod, controllerClass, controller, objects);
    }
  }

  /**
   * Invokes the method of the given action name on the given controller.
   * 
   * @param actionName
   * @param baseMethod
   * @param controllerClass
   * @param controller
   * @param objects
   * @throws NoSuchMethodException
   * @throws SecurityException
   * 
   * @throws NoSuchMethodException
   * @throws IllegalAccessException
   * @throws IllegalArgumentException
   * @throws IllegalAccessException
   * @throws InvocationTargetException
   */
  private void dispatchSuccess(String actionName, Method baseMethod, Class<?> controllerClass,
      Object controller, Object[] objects) throws IllegalAccessException, NoSuchMethodException
  {
    try
    {
      Method method = controllerClass
          .getMethod(actionName, ( (Class[]) baseMethod.getParameterTypes() ));
      method.invoke(controller, objects);
    }
    catch (InvocationTargetException e)
    {
      throw new RuntimeException(e.getTargetException());
    }
  }

  /**
   * Invokes the failure method of the given action for the given controller.
   * 
   * @param actionName
   * @param baseClass
   * @param controllerClass
   * @param controller
   * @param objects
   * 
   * @throws IllegalAccessException
   * @throws NoSuchMethodException
   */
  private void dispatchFailure(String actionName, Class<?> baseClass, Class<?> controllerClass,
      Object controller, Object[] objects) throws IllegalAccessException, NoSuchMethodException
  {
    try
    {

      String failureName = "fail" + GenerationUtil.upperFirstCharacter(actionName);
      Method failureBase = RequestScraper.getMethod(failureName, baseClass);

      controllerClass.getMethod(failureName, ( (Class[]) failureBase.getParameterTypes() )).invoke(
          controller, objects);
    }
    catch (InvocationTargetException e)
    {
      throw new RuntimeException(e.getTargetException());
    }
  }

  /**
   * Checks that the Servlet action can be invoked with the given method. If so
   * then it invokes the method.
   * 
   * @param req
   * @param resp
   * @param servletMethod
   */
  private void checkAndDispatch(HttpServletRequest req, HttpServletResponse resp,
      ServletMethod servletMethod)
  {
    String servletPath = ServletDispatcher.getServletPath(req);
    servletPath = servletPath.substring(0, servletPath.lastIndexOf("."));
    RequestManager manager = new RequestManager(req);

    try
    {
      int index = servletPath.lastIndexOf(".");
      String actionName = servletPath.substring(index + 1);
      String controllerName = servletPath.substring(0, index).replace("/", "");

      Class<?> baseClass = LoaderDecorator.load(controllerName + "Base");
      Method baseMethod = RequestScraper.getMethod(actionName, baseClass);

      if (baseMethod != null)
      {
        ActionParameters annotation = baseMethod.getAnnotation(ActionParameters.class);

        // POST methods cannot be invoked through GETS
        if (annotation.post() && servletMethod.equals(ServletMethod.GET))
        {
          String msg = "The uri [" + servletPath + "] can only be accessed by a post method";
          throw new IllegalURIMethodException(msg, req.getLocale(), servletPath);
        }
        else
        {
          dispatch(req, resp, manager, actionName, controllerName, baseClass, baseMethod);
        }
      }
      else
      {
        String msg = "A servlet at the uri [" + servletPath + "] does not exist.";
        throw new UnknownServletException(msg, req.getLocale(), servletPath);
      }
    }
    catch (ApplicationException e)
    {
      String msg = "A servlet at the uri [" + servletPath + "] does not exist.";
      throw new UnknownServletException(msg, req.getLocale(), servletPath);
    }
    catch (NoSuchMethodException e)
    {
      String msg = "A servlet at the uri [" + servletPath + "] does not exist.";
      throw new UnknownServletException(msg, req.getLocale(), servletPath);
    }
    catch (InstantiationException e)
    {
      String msg = "A servlet at the uri [" + servletPath + "] does not exist.";
      throw new UnknownServletException(msg, req.getLocale(), servletPath);
    }
    catch (IllegalAccessException e)
    {
      String msg = "A servlet at the uri [" + servletPath + "] does not exist.";
      throw new UnknownServletException(msg, req.getLocale(), servletPath);
    }
    catch (InvocationTargetException e)
    {
      throw new RuntimeException(e.getTargetException());
    }
  }

  private static final String getServletPath(HttpServletRequest request)
  {
    String servletPath = request.getServletPath();

    if (!"".equals(servletPath))
    {
      return servletPath;
    }

    String requestUri = request.getRequestURI();
    int startIndex = request.getContextPath().equals("") ? 0 : request.getContextPath().length();
    int endIndex = request.getPathInfo() == null ? requestUri.length() : requestUri.indexOf(request
        .getPathInfo());

    return requestUri.substring(startIndex, endIndex);
  }
}
