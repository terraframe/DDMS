package com.runwaysdk.controller;

import java.util.Locale;

import com.runwaysdk.business.ComponentDTO;
import com.runwaysdk.transport.metadata.AttributeMdDTO;

public abstract class MomentParseExceptionDTO extends ParseProblemDTO
{
  private String format;

  public MomentParseExceptionDTO(ComponentDTO component, AttributeMdDTO attributeMd, Locale locale, String value, String format)
  {
    super(component, attributeMd, locale, value);
    
    this.format = format;
  }

  public MomentParseExceptionDTO(String attributeName, Locale locale, String value, String format)
  {
    super(attributeName, locale, value);
    
    this.format = format;
  }
  
  protected String getFormat()
  {
    return this.format;
  }
}
