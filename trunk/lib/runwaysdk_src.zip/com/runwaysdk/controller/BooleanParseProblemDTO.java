package com.runwaysdk.controller;

import java.util.Locale;

import com.runwaysdk.CommonExceptionMessageLocalizer;
import com.runwaysdk.business.ComponentDTO;
import com.runwaysdk.transport.metadata.AttributeMdDTO;

public class BooleanParseProblemDTO extends ParseProblemDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = 2338258039783064479L;

  public BooleanParseProblemDTO(ComponentDTO component, AttributeMdDTO attributeMd, Locale locale, String value)
  {
    super(component, attributeMd, locale, value);
  }

  public BooleanParseProblemDTO(String attributeName, Locale locale, String value)
  {
    super(attributeName, locale, value);
  }
  
  @Override
  public String getMessage()
  {
    return CommonExceptionMessageLocalizer.booleanParseException(this.getLocale(), this.getAttributeLabel(), this.getValue());
  }
}
