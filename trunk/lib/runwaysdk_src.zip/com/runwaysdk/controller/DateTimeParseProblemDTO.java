package com.runwaysdk.controller;

import java.util.Locale;

import com.runwaysdk.CommonExceptionMessageLocalizer;
import com.runwaysdk.business.ComponentDTO;
import com.runwaysdk.transport.metadata.AttributeMdDTO;

public class DateTimeParseProblemDTO extends MomentParseExceptionDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = 5283207790238093955L;

  public DateTimeParseProblemDTO(ComponentDTO component, AttributeMdDTO attributeMd, Locale locale, String value, String format)
  {
    super(component, attributeMd, locale, value, format);
  }

  public DateTimeParseProblemDTO(String attributeName, Locale locale, String value, String format)
  {
    super(attributeName, locale, value, format);
  }
  
  @Override
  public String getMessage()
  {
    return CommonExceptionMessageLocalizer.dateTimeParseException(this.getLocale(), this.getAttributeLabel(), this.getValue(), this.getFormat());
  }
}
