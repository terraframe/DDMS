package com.runwaysdk.controller;

import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import com.runwaysdk.business.MutableDTO;
import com.runwaysdk.business.RelationshipDTO;
import com.runwaysdk.constants.ClientConstants;
import com.runwaysdk.constants.ClientRequestIF;
import com.runwaysdk.constants.Constants;
import com.runwaysdk.generation.loader.LoaderDecorator;
import com.runwaysdk.transport.metadata.AttributeMdDTO;
import com.runwaysdk.transport.metadata.AttributeStructMdDTO;
import com.runwaysdk.util.Converter;

public class ConverterFacade
{
  private String             type;

  private String             name;

  private HttpServletRequest req;

  public ConverterFacade(String type, String name, HttpServletRequest req)
  {
    this.type = type;
    this.name = name;
    this.req = req;
  }

  public Object convert()
  {
    Class<?> c = LoaderDecorator.load(type);
    String value = req.getParameter(name);

    return convertValue(c, value);
  }

  private <T> T convertValue(Class<T> c, String value)
  {
    if (c.isAssignableFrom(Short.class))
    {
      return c.cast(Short.parseShort(value));
    }
    else if (c.isAssignableFrom(Integer.class))
    {
      return c.cast(Integer.parseInt(value));
    }
    else if (c.isAssignableFrom(Long.class))
    {
      return c.cast(Long.parseLong(value));
    }
    else if (c.isAssignableFrom(Boolean.class))
    {
      return c.cast(Boolean.parseBoolean(value));
    }
    else if (c.isAssignableFrom(Float.class))
    {
      return c.cast(Float.parseFloat(value));
    }
    else if (c.isAssignableFrom(Double.class))
    {
      return c.cast(Double.parseDouble(value));
    }
    else if (c.isAssignableFrom(String.class))
    {
      return c.cast(value);
    }
    else if (c.isAssignableFrom(Character.class))
    {
      return c.cast(new Character(value.charAt(0)));
    }
    else if (c.isAssignableFrom(Date.class))
    {
      try
      {
        //First try a dateTime format
        SimpleDateFormat dateTime = new SimpleDateFormat(Constants.DATETIME_FORMAT, req.getLocale());
        return c.cast(dateTime.parse(value));
      }
      catch (ParseException e)
      {
        //Next Try a date format
        try
        {
          SimpleDateFormat date = new SimpleDateFormat(Constants.DATE_FORMAT, req.getLocale());

          return c.cast(date.parse(value));
        }
        catch (ParseException e1)
        {
          //Finally try a time format
          try
          {
            SimpleDateFormat time = new SimpleDateFormat(Constants.TIME_FORMAT, req.getLocale());

            return c.cast(time.parse(value));
          }
          catch (ParseException e2)
          {
            //FIXME Change exception type
            throw new RuntimeException(e2);
          }
        }        
      }
    }
    // c is not primitive, must be a metadata defined type
    else
    {
      try
      {
        return this.convertDTO(c);
      }
      catch (Exception e)
      {
        throw new RuntimeException(e.getLocalizedMessage());
      }
    }
  }

  @SuppressWarnings("unchecked")
  private <T> T convertDTO(Class<T> c) throws Exception
  {
    ClientRequestIF clientRequestIF = (ClientRequestIF) req.getAttribute(ClientConstants.CLIENTREQUEST);
    MutableDTO mutableDTO = this.getNewInstance(c, clientRequestIF);

    // DTO value hash: name.accessorName.structAcessorName
    for (String accessorName : mutableDTO.getAccessorNames())
    {
      String accessorMd = "get" + accessorName.substring(0, 1).toUpperCase() + accessorName.substring(1) + "Md";
      AttributeMdDTO attributeDTO = (AttributeMdDTO) c.getMethod(accessorMd).invoke(mutableDTO);

      if (attributeDTO instanceof AttributeStructMdDTO)
      {
        // attribute is a struct attribute
        String methodName = "get" + accessorName.substring(0, 1).toUpperCase() + accessorName.substring(1);
        MutableDTO structDTO = (MutableDTO) c.getMethod(methodName).invoke(mutableDTO);

        // Load all of the attributes in the structDTO
        for (String structAccessor : structDTO.getAccessorNames())
        {
          this.setValue(structDTO, structAccessor, req.getParameter(name + "." + accessorName + "." + structAccessor));
        }
      }
      else
      {
        // Get the name of the setter method
        this.setValue(mutableDTO, accessorName, req.getParameter(name + "." + accessorName));
      }
    }

    return (T) mutableDTO;
  }

  private <T> void setValue(MutableDTO mutableDTO, String accessorName, String genericValue) throws Exception
  {
    if(genericValue == null)
    {
      return;
    }
    
    Object value = null;
    
    // Get the setter method(this method may be overloaded)
    Method method = this.getAttributeSetter(mutableDTO, accessorName);

    // Convert the generic String to a java object    
    try
    {
      //Get the default converter
      Converter converter = this.getConverter(mutableDTO, accessorName);
      
      value = converter.parse(genericValue, req.getLocale());
    }
    catch(Exception e)
    {
      //A default converter has not been defined, thus use standard conversions
      Class<?> parameterClass = method.getParameterTypes()[0];

      // Convert the request parameter to its primitive type
      value = convertValue(parameterClass, genericValue);
    }
    
    // Invoke the setter method
    if(value != null)
    {
      method.invoke(mutableDTO, value);
    }
  }

  private Method getAttributeSetter(MutableDTO mutableDTO, String accessorName) throws Exception
  {
    Class<?> c = mutableDTO.getClass();
    String methodName = "set" + accessorName.substring(0, 1).toUpperCase() + accessorName.substring(1);
    String accessorMd = "get" + accessorName.substring(0, 1).toUpperCase() + accessorName.substring(1) + "Md";

    AttributeMdDTO attributeDTO = (AttributeMdDTO) c.getMethod(accessorMd).invoke(mutableDTO);

    return c.getMethod(methodName, attributeDTO.getJavaType());
  }
  
  private Converter getConverter(MutableDTO mutableDTO, String accessorName) throws Exception
  {
    Class<?> c = mutableDTO.getClass();
    String methodName = "get" + accessorName.substring(0, 1).toUpperCase() + accessorName.substring(1) + "Converter";

    return (Converter) c.getMethod(methodName).invoke(mutableDTO);
  }

  private <T> MutableDTO getNewInstance(Class<T> c, ClientRequestIF clientRequestIF) throws Exception
  {
    if (RelationshipDTO.class.isAssignableFrom(c))
    {
      String parentId = req.getParameter("#" + name + ".parent.id");
      String childId = req.getParameter("#" + name + ".child.id");

      return (MutableDTO) c.getConstructor(ClientRequestIF.class, String.class, String.class).newInstance(clientRequestIF, parentId, childId);
    }

    return (MutableDTO) c.getConstructor(ClientRequestIF.class).newInstance(clientRequestIF);
  }

  public static Method getMethod(String methodName, Class<?> c)
  {
    Method[] methods = c.getMethods();

    // Get the method corresponding to the action name.
    // This is ok because method overloading is not allowed
    // in the metadata.
    for (Method m : methods)
    {
      if (m.getName().equals(methodName))
      {
        return m;
      }
    }

    return null;
  }

}
