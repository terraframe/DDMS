package com.runwaysdk.constants;

import com.runwaysdk.constants.ProfileManager;
import com.runwaysdk.constants.ProfileReader;



/**
 * Convenience class that allows easy access to the client.properties file.
 *
 * @author Eric
 */
public class ClientProperties
{
  /**
   * The client.properties configuration file
   */
  private ProfileReader props;
  
  /**
   * A holder class for access to the singleton. Allows for lazy instantiation and thread
   * safety because the class is not loaded until the first access to INSTANCE.
   */
  private static class Singleton
  {
    private static final ClientProperties INSTANCE = new ClientProperties();
  }
  
  /**
   * Private constructor loads the client.properties configuration
   */
  private ClientProperties()
  {
    props = ProfileManager.getBundle("client/client.properties");
  }
  
  public static String getConnectionsFile()
  {
    return Singleton.INSTANCE.props.getString("connections.file");
  }
  
  public static String getConnectionsSchemaFile()
  {
    return Singleton.INSTANCE.props.getString("connectionsSchema.file");
  }
  
  public static String getLibDirectory()
  {
    return Singleton.INSTANCE.props.getString("clientLibDirectory");
  }

  public static String getFileCacheDirectory()
  {
    return Singleton.INSTANCE.props.getString("fileCacheDirectory")+"/";
  }
  
  public static boolean getEnableFileCache()
  {
    return Singleton.INSTANCE.props.getBoolean("enableFileCache");
  }
  
  /**
   * Gets the directory containing the runway javascript.
   */
  public static String getJavascriptDir()
  {
    return Singleton.INSTANCE.props.getString("ajax.javascript");
  }
  
  public static Integer getRMIAppletPort()
  {
    return Singleton.INSTANCE.props.getInteger("applet.rmi.port");
  }
  
  public static String getRMIAppletName()
  {
    return Singleton.INSTANCE.props.getString("applet.rmi.name");
  }
  
  public static boolean getJavascriptGzip()
  {
    return Boolean.parseBoolean(Singleton.INSTANCE.props.getString("javascript.gzip"));
  }
  
  public static boolean getJavascriptMinify()
  {
    return Boolean.parseBoolean(Singleton.INSTANCE.props.getString("javascript.minify"));
  }
  
  public static boolean getJavascriptCache()
  {
    return Boolean.parseBoolean(Singleton.INSTANCE.props.getString("javascript.cache"));
  }

  public static String getDefaultConverter()
  {
    return Singleton.INSTANCE.props.getString("default.converter");
  }
}
