package com.runwaysdk.constants;

import com.runwaysdk.constants.Constants;


public class JavaClientRequestInfo
{
  public static final String CLASS = Constants.ROOT_PACKAGE+".request.JavaClientRequest";
}
