package com.runwaysdk.constants;

public class WebXmlMappings
{
  /**
   * The Runway namespace used with mappings in the web.file for JEE deploy
   * environments. This namespace is used to prepend paths to filters, servlets,
   * and other resources.
   */
  public static final String RUNWAY_NAMESPACE = "Runway";
  
  public static final String SECURE_UPLOAD_ENDPOINT = RUNWAY_NAMESPACE + "/SecureFileUploadServlet";
  
  public static final String SECURE_DOWNLOAD_ENDPOINT = RUNWAY_NAMESPACE + "/SecureFileDownloadServlet";
  
  public static final String WEB_UPLOAD_ENDPOINT = RUNWAY_NAMESPACE + "/WebFileUploadServlet";
  
  public static final String WEB_DOWNLOAD_ENDPOINT = RUNWAY_NAMESPACE + "/WebFileDownloadServlet";
}
