package com.runwaysdk.constants;

public class ClientConstants
{
  /**
   * The client request.
   */
  public static final String CLIENTREQUEST             = "RUNWAY_ClientRequest";

  /**
   * The session session.
   */
  public static final String CLIENTSESSION             = "RUNWAY_ClientSession";

  /**
   * DTO of the user that is currently logged into the session.
   */
  public static final String CURRENTUSER               = "RUNWAY_CurrentUser";
  
  /**
   * Name of the type on which an attribute file is defined.
   */
  public static final String VAULT_ATTRIBUTE_FILE_TYPE = "RUNWAY_VaultAttributeFileType";

  /**
   * Name of the attribute file.
   */
  public static final String VAULT_ATTRIBUTE_FILE_NAME = "RUNWAY_VaultAttributeFileName";
  
}
