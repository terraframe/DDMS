package com.runwaysdk.constants;

/**
 * Constants for a URI query string
 */
public class QueryString
{
  public static final String PAGE_NUMBER = "ns-pageNumber";
  
  public static final String PAGE_SIZE = "ns-pageSize";
  
  public static final String SORT = "ns-sort";
  
  public static final String ORDER = "ns-order";
  
  public static final int DEFAULT_PAGE_NUMBER = 1;
  
  public static final int DEFAULT_PAGE_SIZE = 20;
  
  public static final String DELIM = "&";
  
  public static final String KEYVALUE = "=";
  
  /**
   * The key of the query string that denotes an empty query (no results).
   */
  public static final String EMPTY_QUERY = "ns-empty_query";
  
  /**
   * The key of the query string that denotes if this request is for
   * a new results component (e.g., ViewAllResults or NodeSearchResults).
   * The value of this key must be set to true in order to be valid.
   */
  public static final String NEW_RESULTS = "ns-new_results";
  
  /**
   * The key whose value is a groovy query string.
   */
  public static final String GROOVY = "ns-groovy";
  
  /**
   * The key whose value is a json query string
   */
  public static final String JSON_QUERY = "ns-json";
  
  /**
   * Order by ascending.
   */
  public static final String ASC                    = "asc";
  
  /**
   * Order by descending.
   */
  public static final String DESC                   = "desc";
  
  /**
   * The delimeter to use for sorting on an attribute defined
   * by an attribute struct. The internal convention to use is
   * "structName-structAttributeName".
   */
  public static final String STRUCT_SORT_DELIM = "-";
  
  public static final int STRUCT_SORT_STRUCT_INDEX = 0;
  
  public static final int STRUCT_SORT_ATTRIBUTE_INDEX = 1;
}
