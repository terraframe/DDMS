package com.runwaysdk.constants;

import com.runwaysdk.constants.Constants;


public class JSONJavaRequestInfo
{
  public static final String CLASS = Constants.ROOT_PACKAGE+".web.json.JSONJavaClientRequest";
}
