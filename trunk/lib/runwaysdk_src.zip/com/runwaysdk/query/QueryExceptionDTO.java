package com.runwaysdk.query;

import com.runwaysdk.dataaccess.ProgrammingErrorExceptionDTO;

public class QueryExceptionDTO extends ProgrammingErrorExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -5830231208028966947L;

  /**
   * Constructs a new QueryExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public QueryExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
