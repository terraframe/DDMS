package com.runwaysdk.session;

import com.runwaysdk.business.BusinessExceptionDTO;

public class InvalidSessionExceptionDTO  extends BusinessExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 1332856313632062323L;

  /**
   * Constructs a new InvalidSessionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public InvalidSessionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
