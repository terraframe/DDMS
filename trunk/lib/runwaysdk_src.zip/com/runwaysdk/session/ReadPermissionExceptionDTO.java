package com.runwaysdk.session;


public class ReadPermissionExceptionDTO extends PermissionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -2133779700913417398L;

  /**
   * Constructs a new ReadPermissionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public ReadPermissionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
