package com.runwaysdk.session;

public class DeleteParentPermissionExceptionDTO extends RelationshipPermissionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -6479385503113949198L;

  /**
   * Constructs a new DeleteParentPermissionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public DeleteParentPermissionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
