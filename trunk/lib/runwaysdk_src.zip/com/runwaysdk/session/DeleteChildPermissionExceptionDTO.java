package com.runwaysdk.session;

public class DeleteChildPermissionExceptionDTO extends RelationshipPermissionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 870978935292853363L;

  /**
   * Constructs a new DeleteChildPermissionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public DeleteChildPermissionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
