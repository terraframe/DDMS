package com.runwaysdk.session;

import com.runwaysdk.business.BusinessExceptionDTO;

public class ImportDomainExecuteExceptionDTO extends BusinessExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 2632487208032808142L;

  /**
   * Constructs a new ImportDomainExecuteExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public ImportDomainExecuteExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
