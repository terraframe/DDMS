package com.runwaysdk.session;

public class CreatePermissionExceptionDTO extends PermissionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -5665910851200696258L;

  /**
   * Constructs a new CreatePermissionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public CreatePermissionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
