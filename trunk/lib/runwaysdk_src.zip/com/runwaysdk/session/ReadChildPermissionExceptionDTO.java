package com.runwaysdk.session;

public class ReadChildPermissionExceptionDTO extends RelationshipPermissionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 5377351242923758385L;

  /**
   * Constructs a new ReadChildPermissionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public ReadChildPermissionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
