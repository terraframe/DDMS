package com.runwaysdk.session;

public class GrantAttributeStatePermissionExceptionDTO extends PermissionExceptionDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = -6230925136786494251L;

  /**
   * Constructs a new GrantAttributeStatePermissionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public GrantAttributeStatePermissionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
