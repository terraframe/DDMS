package com.runwaysdk.session;

import com.runwaysdk.business.BusinessExceptionDTO;

public class GroovyQueryExecuteExceptionDTO extends BusinessExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 2535691594539798233L;

  /**
   * Constructs a new GroovyQueryExecuteExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public GroovyQueryExecuteExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
