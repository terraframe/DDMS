package com.runwaysdk.session;

import com.runwaysdk.business.BusinessExceptionDTO;

public class ReadTypePermissionExceptionDTO extends BusinessExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -7604915817781825153L;

  /**
   * Constructs a new ReadTypePermissionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public ReadTypePermissionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
