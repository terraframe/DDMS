package com.runwaysdk.session;

public class AddParentPermissionExceptionDTO extends RelationshipPermissionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 1378061823145325178L;

  /**
   * Constructs a new AddParentPermissionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public AddParentPermissionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
