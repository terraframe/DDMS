package com.runwaysdk.session;

import com.runwaysdk.business.BusinessExceptionDTO;

public class RoleManagementException_ADDDTO extends BusinessExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 7199781305296672943L;

  /**
   * Constructs a new RoleManagementException_ADDDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RoleManagementException_ADDDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
