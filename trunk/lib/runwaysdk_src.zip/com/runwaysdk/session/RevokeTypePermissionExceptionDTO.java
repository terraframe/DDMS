package com.runwaysdk.session;

public class RevokeTypePermissionExceptionDTO extends PermissionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 5842922894322007330L;

  /**
   * Constructs a new RevokeTypePermissionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RevokeTypePermissionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
