package com.runwaysdk.session;

public class DeletePermissionExceptionDTO extends PermissionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -235959057713760404L;

  /**
   * Constructs a new DeletePermissionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public DeletePermissionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
