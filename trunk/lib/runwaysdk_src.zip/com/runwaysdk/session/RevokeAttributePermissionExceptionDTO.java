package com.runwaysdk.session;

public class RevokeAttributePermissionExceptionDTO extends PermissionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -5209620057181092563L;

  /**
   * Constructs a new RevokeAttributePermissionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RevokeAttributePermissionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
