package com.runwaysdk.session;

import com.runwaysdk.business.LoginExceptionDTO;

public class InvalidLoginExceptionDTO extends LoginExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 4177539898852360046L;

  /**
   * Constructs a new InvalidLoginExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public InvalidLoginExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
