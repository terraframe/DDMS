package com.runwaysdk.session;

public abstract class RelationshipPermissionExceptionDTO extends PermissionExceptionDTO
{
  /**
   * Constructs a new RelationshipPermissionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RelationshipPermissionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
