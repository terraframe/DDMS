package com.runwaysdk.session;

import com.runwaysdk.business.BusinessExceptionDTO;

public abstract class PermissionExceptionDTO extends BusinessExceptionDTO
{
  /**
   * Constructs a new PermissionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public PermissionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
