package com.runwaysdk.session;

import com.runwaysdk.business.LoginExceptionDTO;

public class MaximumSessionsExceptionDTO extends LoginExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -8750535796308786965L;

  /**
   * Constructs a new MaximumSessionsExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public MaximumSessionsExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
