package com.runwaysdk.session;


public class AddChildPermissionExceptionDTO extends RelationshipPermissionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 6312926445670083319L;

  /**
   * Constructs a new AddChildPermissionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public AddChildPermissionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
