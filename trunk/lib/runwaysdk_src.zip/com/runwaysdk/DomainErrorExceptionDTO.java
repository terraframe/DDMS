package com.runwaysdk;

import com.runwaysdk.RunwayExceptionDTO;


public class DomainErrorExceptionDTO extends RunwayExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 4162075678266547739L;

  /**
   * Constructs a new DomainErrorExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public DomainErrorExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
