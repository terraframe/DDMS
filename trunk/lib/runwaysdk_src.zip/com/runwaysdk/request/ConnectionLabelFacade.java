package com.runwaysdk.request;

import java.lang.reflect.Method;

import com.runwaysdk.constants.RequestManagerInfo;
import com.runwaysdk.generation.loader.LoaderDecorator;
import com.runwaysdk.request.ClientRequestException;
import com.runwaysdk.request.ConnectionLabel;

/**
 * A convience class which bridges RequestMangager and ClientRequest
 * methods between the server and the client through the use
 * of reflection. This is done for compilation reasons.
 * These methods just delegate to existing methods written
 * for the client.
 *  
 * @author Justin
 *
 */
public class ConnectionLabelFacade
{  
 
  /**
   * Returns the default Connection
   * @return
   */
  public static ConnectionLabel getConnection()
  {
    try
    {
      Class<?> c = LoaderDecorator.load(RequestManagerInfo.CLASS);
      Method method = c.getMethod("getDefaultConnection");
      ConnectionLabel connection = (ConnectionLabel) method.invoke(null);
      
      return connection;
    }
    catch (Exception e)
    {
      throw new ClientRequestException(e);
    }
  }
  
  /**
   * Returns the Connection mapped to the label
   * 
   * @param label The label of the connection
   * @return
   */
  public static ConnectionLabel getConnection(String label)
  {
    try
    {
      Class<?> c = LoaderDecorator.load(RequestManagerInfo.CLASS);
      Method method = c.getMethod("getConnection", String.class);
      ConnectionLabel connection = (ConnectionLabel) method.invoke(null, label);
      
      return connection;
    }
    catch (Exception e)
    {
      throw new ClientRequestException(e);
    }
  }
}
