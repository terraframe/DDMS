package com.runwaysdk.facade;

import com.runwaysdk.RunwayExceptionDTO;

public class GroovyQueryExceptionDTO extends RunwayExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -5324186832996567233L;

  /**
   * Constructs a new GroovyQueryExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public GroovyQueryExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
