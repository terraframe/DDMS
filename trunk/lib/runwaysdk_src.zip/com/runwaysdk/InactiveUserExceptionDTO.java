package com.runwaysdk;

import com.runwaysdk.business.LoginExceptionDTO;

public class InactiveUserExceptionDTO extends LoginExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -7951384296422075721L;

  /**
   * Constructs a new InactiveUserExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public InactiveUserExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
