package com.runwaysdk.dataaccess;

public class AttributeDoesNotExistExceptionDTO extends DataAccessExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -5845807236644507091L;

  /**
   * Constructs a new AttributeDoesNotExistExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public AttributeDoesNotExistExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
