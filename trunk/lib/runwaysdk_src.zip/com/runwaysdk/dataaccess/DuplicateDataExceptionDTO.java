package com.runwaysdk.dataaccess;


public class DuplicateDataExceptionDTO extends DataAccessExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 6149921899851194095L;

  /**
   * Constructs a new DuplicateDataExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public DuplicateDataExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
