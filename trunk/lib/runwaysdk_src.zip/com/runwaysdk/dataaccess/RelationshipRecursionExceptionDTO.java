package com.runwaysdk.dataaccess;

public class RelationshipRecursionExceptionDTO extends RelationshipConstraintExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 2494094903280032900L;

  /**
   * Constructs a new RelationshipRecursionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RelationshipRecursionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
