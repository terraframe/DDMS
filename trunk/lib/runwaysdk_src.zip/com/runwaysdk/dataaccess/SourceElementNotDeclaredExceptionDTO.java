package com.runwaysdk.dataaccess;

public class SourceElementNotDeclaredExceptionDTO extends DataAccessExceptionDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

  public SourceElementNotDeclaredExceptionDTO(String type, String localizedMessage,
      String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
    // TODO Auto-generated constructor stub
  }
  
  

}
