package com.runwaysdk.dataaccess;

/**
 * Rolenames must be namespaced
 * 
 * @author jsmethie
 */
public class RoleNamespaceExceptionDTO extends DataAccessExceptionDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = -6022840509976660169L;

  /**
   * Constructs a new {@link RoleNamespaceExceptionDTO} with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RoleNamespaceExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }

}
