package com.runwaysdk.dataaccess;

public class XSDDefinitionNotResolvedExceptionDTO extends DataAccessExceptionDTO
{

  public XSDDefinitionNotResolvedExceptionDTO(String type, String localizedMessage,
      String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
    // TODO Auto-generated constructor stub
  }

  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  
  

}
