package com.runwaysdk.dataaccess;

import com.runwaysdk.RunwayExceptionDTO;

public class ProgrammingErrorExceptionDTO extends RunwayExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -3827329559556869456L;

  /**
   * Constructs a new ProgrammingErrorExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public ProgrammingErrorExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
