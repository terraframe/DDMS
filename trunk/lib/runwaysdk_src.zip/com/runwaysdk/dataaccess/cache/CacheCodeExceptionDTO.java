package com.runwaysdk.dataaccess.cache;

import com.runwaysdk.dataaccess.DataAccessExceptionDTO;

public class CacheCodeExceptionDTO extends DataAccessExceptionDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = 9036608495619853171L;

  /**
   * Constructs a new CacheCodeExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public CacheCodeExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
