package com.runwaysdk.dataaccess.cache;

import com.runwaysdk.dataaccess.DataAccessExceptionDTO;

public class DataNotFoundExceptionDTO extends DataAccessExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 5661295033594624993L;

  /**
   * Constructs a new DataNotFoundExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public DataNotFoundExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
