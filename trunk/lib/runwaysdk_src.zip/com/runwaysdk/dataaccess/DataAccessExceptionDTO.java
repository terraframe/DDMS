package com.runwaysdk.dataaccess;

import com.runwaysdk.RunwayExceptionDTO;

public class DataAccessExceptionDTO extends RunwayExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 8942588338478876109L;

  /**
   * Constructs a new DataAccessExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public DataAccessExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
