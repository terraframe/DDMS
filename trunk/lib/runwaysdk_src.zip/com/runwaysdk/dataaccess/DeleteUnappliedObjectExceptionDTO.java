package com.runwaysdk.dataaccess;

public class DeleteUnappliedObjectExceptionDTO extends DataAccessExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -4634213789198278072L;

  /**
   * Constructs a new DeleteUnappliedObjectExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public DeleteUnappliedObjectExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
