package com.runwaysdk.dataaccess.attributes;

public class InvalidReferenceExceptionDTO extends AttributeExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -4518522678162533811L;

  /**
   * Constructs a new InvalidReferenceExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public InvalidReferenceExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
