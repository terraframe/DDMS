package com.runwaysdk.dataaccess.attributes;

public class InvalidAttributeTypeExceptionDTO extends AttributeExceptionDTO
{
  /**
   *
   */
  private static final long serialVersionUID = 5524598538328624557L;

  /**
   * Constructs a new InvalidReferenceAttributeExceptionDTO with the specified localized message from the server.
   *
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public InvalidAttributeTypeExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }

}
