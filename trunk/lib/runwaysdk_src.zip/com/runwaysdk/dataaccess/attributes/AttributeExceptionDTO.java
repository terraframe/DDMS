package com.runwaysdk.dataaccess.attributes;

import com.runwaysdk.dataaccess.DataAccessExceptionDTO;

public class AttributeExceptionDTO extends DataAccessExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -6888926619182744738L;

  /**
   * Constructs a new AttributeExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public AttributeExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
