package com.runwaysdk.dataaccess.attributes;

public class EncryptionExceptionDTO extends AttributeExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 2423011368543250194L;

  /**
   * Constructs a new EncryptionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public EncryptionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
