package com.runwaysdk.dataaccess.attributes;

public class AttributeValueExceptionDTO extends AttributeExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -1909559422508316519L;

  /**
   * Constructs a new AttributeValueExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public AttributeValueExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
