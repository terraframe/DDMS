package com.runwaysdk.dataaccess.attributes;

public class AttributeLengthExceptionDTO extends AttributeExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -1700769550972940574L;

  /**
   * Constructs a new AttributeLengthExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public AttributeLengthExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
