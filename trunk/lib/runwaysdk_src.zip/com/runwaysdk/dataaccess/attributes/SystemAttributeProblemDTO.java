package com.runwaysdk.dataaccess.attributes;

import com.runwaysdk.business.AttributeProblemDTO;
import com.runwaysdk.constants.SystemAttributeProblemDTOInfo;

public class SystemAttributeProblemDTO extends AttributeProblemDTO
{

  public static final String CLASS = SystemAttributeProblemDTOInfo.CLASS;
  
  /**
   * 
   */
  private static final long serialVersionUID = -8262754981308618167L;

  /**
   * Constructs a new SystemAttributeProblemDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param componentId id of the containing component.
   * @param definingType type of the containing component.
   * @param definingTypeDisplayLabel display label of the type of the containing component.
   * @param attributeName name of the attribute.
   * @param attributeDisplayLabel display label of the attribute.
   * @param localizedMessage end user error message.
   */
  public SystemAttributeProblemDTO(
      String type, String componentId, 
      String definingType, String definingTypeDisplayLabel,
      String attributeName, String attributeDisplayLabel,
      String localizedMessage)
  {
    super(type, componentId, 
        definingType, definingTypeDisplayLabel,
        attributeName, attributeDisplayLabel,
        localizedMessage);
  }
}
