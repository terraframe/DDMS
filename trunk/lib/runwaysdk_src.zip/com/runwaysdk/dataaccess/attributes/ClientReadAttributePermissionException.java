package com.runwaysdk.dataaccess.attributes;

import java.util.Locale;

import com.runwaysdk.ClientExceptionMessageLocalizer;
import com.runwaysdk.RunwayExceptionDTO;

public class ClientReadAttributePermissionException extends RunwayExceptionDTO
{
  /**
   *
   */
  private static final long serialVersionUID = -8428434469105328450L;

  private Locale locale;

  private String attributeDisplayLabel;

  private String classDisplayLabel;

  public ClientReadAttributePermissionException(String developerMessage, Locale locale, String attributeDisplayLabel, String classDisplayLabel)
  {
    super(ClientReadAttributePermissionException.class.getName(), "", developerMessage);
    this.locale = locale;
    this.attributeDisplayLabel = attributeDisplayLabel;
    this.classDisplayLabel = classDisplayLabel;
  }

  protected Locale getLocale()
  {
    return this.locale;
  }
  
  @Override
  public String getMessage()
  {
    return ClientExceptionMessageLocalizer.clientReadAttributePermissionException(this.getLocale(), attributeDisplayLabel, classDisplayLabel);
  }
}
