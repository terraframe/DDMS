package com.runwaysdk.dataaccess.attributes;

public class AttributeTypeExceptionDTO extends AttributeExceptionDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = -7297809082714016635L;

  /**
   * Constructs a new AttributeTypeExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public AttributeTypeExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
