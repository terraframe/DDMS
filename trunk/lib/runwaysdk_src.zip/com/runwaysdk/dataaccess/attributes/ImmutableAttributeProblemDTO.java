package com.runwaysdk.dataaccess.attributes;

import com.runwaysdk.business.AttributeProblemDTO;
import com.runwaysdk.constants.ImmutableAttributeProblemDTOInfo;

public class ImmutableAttributeProblemDTO extends AttributeProblemDTO
{
  public static final String CLASS = ImmutableAttributeProblemDTOInfo.CLASS;
  
  /**
   * 
   */
  private static final long serialVersionUID = 3301068795102520859L;

  /**
   * Constructs a new ImmutableAttributeProblemDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param componentId id of the containing component.
   * @param definingType type of the containing component.
   * @param definingTypeDisplayLabel display label of the type of the containing component.
   * @param attributeName name of the attribute.
   * @param attributeDisplayLabel display label of the attribute.
   * @param localizedMessage end user error message.
   */
  public ImmutableAttributeProblemDTO(
      String type, String componentId, 
      String definingType, String definingTypeDisplayLabel,
      String attributeName, String attributeDisplayLabel,
      String localizedMessage)
  {
    super(type, componentId, 
        definingType, definingTypeDisplayLabel,
        attributeName, attributeDisplayLabel,
        localizedMessage);
  }
}
