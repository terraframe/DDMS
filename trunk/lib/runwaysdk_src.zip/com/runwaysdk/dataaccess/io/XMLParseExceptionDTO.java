package com.runwaysdk.dataaccess.io;

public class XMLParseExceptionDTO extends XMLExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 4176788415306262582L;

  /**
   * Constructs a new XMLParseExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public XMLParseExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
