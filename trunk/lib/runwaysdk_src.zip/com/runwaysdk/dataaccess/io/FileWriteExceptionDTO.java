package com.runwaysdk.dataaccess.io;

import com.runwaysdk.SystemExceptionDTO;

public class FileWriteExceptionDTO extends SystemExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 1277592448821903387L;

  /**
   * Constructs a new FileWriteExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public FileWriteExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }

  /**
   * Constructs a new FileWriteExceptionDTO to be thrown from the presentation layer.  Message
   * is not localized.
   * 
   * @param developerMessage developer error message.
   */
  public FileWriteExceptionDTO(String developerMessage)
  {
    super("", developerMessage, developerMessage);
    this.setBaseType();
  }
}
