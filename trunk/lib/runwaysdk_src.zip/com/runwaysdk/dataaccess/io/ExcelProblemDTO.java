package com.runwaysdk.dataaccess.io;

import com.runwaysdk.business.RunwayProblemDTO;

public class ExcelProblemDTO extends RunwayProblemDTO
{
  private static final long serialVersionUID = -128368083074952498L;
  
  private int rowNumber;
  
  private String column;

  public ExcelProblemDTO(String type, String localizedMessage, String developerMessage, int rowNumber, String column)
  {
    super(type, localizedMessage);
    this.setDeveloperMessage(developerMessage);
    this.rowNumber = rowNumber;
    this.column = column;
  }

  public int getRowNumber()
  {
    return rowNumber;
  }

  public String getColumn()
  {
    return column;
  }

}
