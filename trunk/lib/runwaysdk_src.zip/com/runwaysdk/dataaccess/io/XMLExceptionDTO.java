package com.runwaysdk.dataaccess.io;

import com.runwaysdk.dataaccess.ProgrammingErrorExceptionDTO;

public class XMLExceptionDTO extends ProgrammingErrorExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 2936162492162128081L;

  /**
   * Constructs a new XMLExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public XMLExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }

  /**
   * Constructs a new XMLExceptionDTO to be thrown from the presentation layer.  Message
   * is not localized.
   * 
   * @param developerMessage developer error message.
   */
  public XMLExceptionDTO(String developerMessage)
  {
    super("", developerMessage, developerMessage);
    this.setBaseType();
  }
}
