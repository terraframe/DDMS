package com.runwaysdk.dataaccess.metadata;

public class CannotAddAttriubteToClassExceptionDTO extends AttributeDefinitionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 3461299268286473529L;

  /**
   * Constructs a new CannotAddAttriubteToClassExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public CannotAddAttriubteToClassExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
