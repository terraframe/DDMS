package com.runwaysdk.dataaccess.metadata;

public class ReservedWordExceptionDTO extends MetaDataExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 1957296960438847839L;

  /**
   * Constructs a new ReservedWordExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public ReservedWordExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
