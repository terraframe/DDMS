package com.runwaysdk.dataaccess.metadata;

import com.runwaysdk.dataaccess.DataAccessExceptionDTO;

public class MetadataCannotBeDeletedExceptionDTO extends DataAccessExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -3361970878326911132L;

  /**
   * Constructs a new MetadataCannotBeDeletedExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public MetadataCannotBeDeletedExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
