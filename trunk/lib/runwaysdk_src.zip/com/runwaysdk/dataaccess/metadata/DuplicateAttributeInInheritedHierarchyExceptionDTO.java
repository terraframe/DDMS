package com.runwaysdk.dataaccess.metadata;

public class DuplicateAttributeInInheritedHierarchyExceptionDTO extends AttributeDefinitionExceptionDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = 5538702684524694556L;

  /**
   * Constructor to set the developer message and the MdAttributeIF of the attribute that is
   * already defined in the inheritance hierarchy of the given class.
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public DuplicateAttributeInInheritedHierarchyExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
