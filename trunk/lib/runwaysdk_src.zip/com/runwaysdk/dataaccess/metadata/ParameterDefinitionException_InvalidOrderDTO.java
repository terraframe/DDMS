package com.runwaysdk.dataaccess.metadata;

public class ParameterDefinitionException_InvalidOrderDTO extends ParameterDefinitionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 6640549396652866374L;

  /**
   * Constructs a new ParameterDefinitionException_InvalidOrderDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public ParameterDefinitionException_InvalidOrderDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
