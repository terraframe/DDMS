package com.runwaysdk.dataaccess.metadata;

public class NoAttributeOnIndexExceptionDTO extends InvalidDefinitionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -9180748915309321663L;

  /**
   * Constructs a new NoAttributeOnIndexExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public NoAttributeOnIndexExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
