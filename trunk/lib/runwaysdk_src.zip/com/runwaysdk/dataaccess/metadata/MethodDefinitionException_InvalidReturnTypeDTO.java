package com.runwaysdk.dataaccess.metadata;

public class MethodDefinitionException_InvalidReturnTypeDTO extends MethodDefinitionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -1212936296753768659L;

  /**
   * Constructs a new MethodDefinitionException_InvalidReturnTypeDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public MethodDefinitionException_InvalidReturnTypeDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
