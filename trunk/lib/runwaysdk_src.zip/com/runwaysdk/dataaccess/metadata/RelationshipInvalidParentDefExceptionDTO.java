package com.runwaysdk.dataaccess.metadata;

import com.runwaysdk.dataaccess.RelationshipConstraintExceptionDTO;

public class RelationshipInvalidParentDefExceptionDTO extends RelationshipConstraintExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 7870961937615447972L;

  /**
   * Constructs a new RelationshipInvalidParentDefExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RelationshipInvalidParentDefExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
