package com.runwaysdk.dataaccess.metadata;

public class ParameterDefinitionException_NameExistsDTO extends ParameterDefinitionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -7011779047535109150L;

  /**
   * Constructs a new ParameterDefinitionException_NameExistsDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public ParameterDefinitionException_NameExistsDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
