package com.runwaysdk.dataaccess.metadata;

public abstract class AttributeDefinitionExceptionDTO extends InvalidDefinitionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -1548691395458152281L;

  /**
   * Constructs a new AttributeDefinitionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public AttributeDefinitionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
