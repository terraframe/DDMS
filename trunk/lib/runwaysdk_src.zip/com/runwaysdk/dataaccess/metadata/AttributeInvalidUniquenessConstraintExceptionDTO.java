package com.runwaysdk.dataaccess.metadata;

public class AttributeInvalidUniquenessConstraintExceptionDTO extends AttributeDefinitionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -1395160406542464886L;

  /**
   * Constructs a new AttributeInvalidUniquenessConstraintExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public AttributeInvalidUniquenessConstraintExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
