package com.runwaysdk.dataaccess.metadata;

public class TupleDefinitionExceptionDTO extends InvalidDefinitionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -6109766941140035556L;

  /**
   * Constructs a new TupleDefinitionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public TupleDefinitionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
