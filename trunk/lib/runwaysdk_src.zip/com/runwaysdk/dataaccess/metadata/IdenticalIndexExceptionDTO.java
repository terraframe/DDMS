package com.runwaysdk.dataaccess.metadata;

public class IdenticalIndexExceptionDTO extends InvalidDefinitionExceptionDTO
{
  /**
   *
   */
  private static final long serialVersionUID = 794598337682994753L;

  /**
   * Constructs a new IdenticalIndexExceptionDTO with the specified localized message from the server.
   *
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public IdenticalIndexExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
