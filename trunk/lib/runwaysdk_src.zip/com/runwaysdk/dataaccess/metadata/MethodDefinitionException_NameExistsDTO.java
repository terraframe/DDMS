package com.runwaysdk.dataaccess.metadata;

public class MethodDefinitionException_NameExistsDTO extends MethodDefinitionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 5152258903122435051L;

  /**
   * Constructs a new MethodDefinitionException_NameExistsDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public MethodDefinitionException_NameExistsDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
