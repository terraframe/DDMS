package com.runwaysdk.dataaccess.metadata;

public abstract class InvalidDefinitionExceptionDTO extends MetaDataExceptionDTO
{
  /**
   *
   */
  private static final long serialVersionUID = 2629339047757985143L;

  /**
   * Constructs a new InvalidDefinitionExceptionDTO with the specified localized message from the server.
   *
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public InvalidDefinitionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
