package com.runwaysdk.dataaccess.metadata;

public class RelationshipDefinitionExceptionDTO extends InvalidDefinitionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -99834504467973075L;

  /**
   * Constructs a new RelationshipDefinitionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RelationshipDefinitionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
