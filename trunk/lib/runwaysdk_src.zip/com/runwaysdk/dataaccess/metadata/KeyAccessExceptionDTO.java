package com.runwaysdk.dataaccess.metadata;

import com.runwaysdk.SystemExceptionDTO;

public class KeyAccessExceptionDTO extends SystemExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 220870098992866459L;

  /**
   * Constructs a new KeyAccessExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public KeyAccessExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
