package com.runwaysdk.dataaccess.metadata;

public class MethodDefinitionExceptionDTO extends InvalidDefinitionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 7001753475024466318L;

  /**
   * Constructs a new MethodDefinitionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public MethodDefinitionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
