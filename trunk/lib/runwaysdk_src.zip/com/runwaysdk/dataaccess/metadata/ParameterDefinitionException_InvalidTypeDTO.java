package com.runwaysdk.dataaccess.metadata;

public class ParameterDefinitionException_InvalidTypeDTO extends ParameterDefinitionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -4646637045602084558L;

  /**
   * Constructs a new ParameterDefinitionException_InvalidTypeDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public ParameterDefinitionException_InvalidTypeDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
