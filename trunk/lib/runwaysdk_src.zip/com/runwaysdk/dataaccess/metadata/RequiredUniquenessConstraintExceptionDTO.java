package com.runwaysdk.dataaccess.metadata;

public class RequiredUniquenessConstraintExceptionDTO extends AttributeDefinitionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -5944892598317919078L;

  /**
   * Constructs a new RequiredUniquenessConstraintExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RequiredUniquenessConstraintExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
