package com.runwaysdk.dataaccess.metadata;

import com.runwaysdk.business.BusinessExceptionDTO;

public class ForbiddenMethodExceptionDTO extends BusinessExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 7703010080419084576L;

  /**
   * Constructs a new ForbiddenMethodExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public ForbiddenMethodExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
