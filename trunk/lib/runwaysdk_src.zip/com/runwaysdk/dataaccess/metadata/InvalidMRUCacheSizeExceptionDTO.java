package com.runwaysdk.dataaccess.metadata;

public class InvalidMRUCacheSizeExceptionDTO extends MetaDataExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -6440464077577977809L;

  /**
   * Constructs a new InvalidMRUCacheSizeExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public InvalidMRUCacheSizeExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
