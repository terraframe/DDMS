package com.runwaysdk.dataaccess.metadata;

import com.runwaysdk.dataaccess.DataAccessExceptionDTO;

public class MetaDataExceptionDTO extends DataAccessExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -6751332951070123737L;

  /**
   * Constructs a new MetaDataExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public MetaDataExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
