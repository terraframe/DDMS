package com.runwaysdk.dataaccess.metadata;

public class MethodDefinitionException_DefiningTypeDTO extends MethodDefinitionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -5317410987850848001L;

  /**
   * Constructs a new MethodDefinitionException_DefiningTypeDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public MethodDefinitionException_DefiningTypeDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
