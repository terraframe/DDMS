package com.runwaysdk.dataaccess.metadata;

public class DuplicateAttributeDefinitionExceptionDTO extends AttributeDefinitionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -7804710393922573222L;

  /**
   * Constructor to set the developer message and the MdAttributeIF of the attribute that is
   * already defined by a subclass of the given class.
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public DuplicateAttributeDefinitionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
