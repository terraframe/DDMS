package com.runwaysdk.dataaccess.metadata;

public class ReferenceAttributeNotReferencingClassExceptionDTO extends AttributeDefinitionExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 8684767086691662663L;

  /**
   * Constructs a new ReferenceAttributeNotReferencingClassExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public ReferenceAttributeNotReferencingClassExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
