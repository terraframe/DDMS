package com.runwaysdk.dataaccess.metadata;

public class NameConventionExceptionDTO extends MetaDataExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -5908418635639973837L;

  /**
   * Constructs a new NameConventionExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public NameConventionExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
