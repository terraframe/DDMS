package com.runwaysdk.dataaccess;

import com.runwaysdk.RunwayExceptionDTO;

public class UnexpectedTypeExceptionDTO extends RunwayExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 581056864183842177L;

  /**
   * Constructs a new UnexpectedTypeExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public UnexpectedTypeExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
