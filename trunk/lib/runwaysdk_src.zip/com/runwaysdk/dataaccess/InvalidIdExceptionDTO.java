package com.runwaysdk.dataaccess;

public class InvalidIdExceptionDTO extends ProgrammingErrorExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -2509423556125979340L;

  /**
   * Constructs a new InvalidIdExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public InvalidIdExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
