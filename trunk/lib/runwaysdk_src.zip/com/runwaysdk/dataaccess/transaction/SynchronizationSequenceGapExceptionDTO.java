package com.runwaysdk.dataaccess.transaction;

public class SynchronizationSequenceGapExceptionDTO extends TransactionImportExceptionDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = -2814183578884202810L;

  /**
   * Constructs a new <code>SynchronizationSequenceGapExceptionDTO</code> with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public SynchronizationSequenceGapExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
