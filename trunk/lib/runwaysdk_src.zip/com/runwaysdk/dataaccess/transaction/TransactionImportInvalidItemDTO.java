package com.runwaysdk.dataaccess.transaction;

public class TransactionImportInvalidItemDTO extends TransactionImportExceptionDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = -2280879716168141704L;

  /**
   * Constructs a new <code>TransactionImportInvalidItemDTO</code> with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public TransactionImportInvalidItemDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
