package com.runwaysdk.dataaccess;

public class CannotDeleteReferencedObjectDTO extends DataAccessExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 8588233455820417062L;

  /**
   * Constructs a new CannotDeleteReferencedObjectDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public CannotDeleteReferencedObjectDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
