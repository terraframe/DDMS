package com.runwaysdk.dataaccess.database;

import com.runwaysdk.RunwayExceptionDTO;

public class AbstractInstantiationExceptionDTO extends RunwayExceptionDTO
{

  /**
   * 
   */
  private static final long serialVersionUID = 7735346370168908174L;

  /**
   * Constructs a new AbstractInstantiationExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public AbstractInstantiationExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
