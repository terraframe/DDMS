package com.runwaysdk.dataaccess.database;

import com.runwaysdk.RunwayExceptionDTO;

public class DatabaseExceptionDTO extends RunwayExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 6454230047209426844L;

  /**
   * Constructs a new DatabaseExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public DatabaseExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
