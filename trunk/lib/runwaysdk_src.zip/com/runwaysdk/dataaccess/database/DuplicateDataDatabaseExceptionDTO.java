package com.runwaysdk.dataaccess.database;

import com.runwaysdk.dataaccess.DuplicateDataExceptionDTO;

public class DuplicateDataDatabaseExceptionDTO extends DuplicateDataExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = 7947732844162356842L;

  /**
   * Constructs a new DuplicateDataDatabaseExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public DuplicateDataDatabaseExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
