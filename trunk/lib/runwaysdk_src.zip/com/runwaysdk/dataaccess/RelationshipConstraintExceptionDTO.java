package com.runwaysdk.dataaccess;

import com.runwaysdk.RunwayExceptionDTO;

public abstract class RelationshipConstraintExceptionDTO extends RunwayExceptionDTO
{
  /**
   * Constructs a new RelationshipConstraintExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public RelationshipConstraintExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
