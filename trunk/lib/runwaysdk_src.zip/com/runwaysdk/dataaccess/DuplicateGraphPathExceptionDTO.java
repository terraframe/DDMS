package com.runwaysdk.dataaccess;

public class DuplicateGraphPathExceptionDTO extends RelationshipConstraintExceptionDTO
{
  /**
   * 
   */
  private static final long serialVersionUID = -2635503114785218618L;

  /**
   * Constructs a new DuplicateGraphPathExceptionDTO with the specified localized message from the server. 
   * 
   * @param type of the runway exception.
   * @param localizedMessage end user error message.
   * @param developerMessage developer error message.
   */
  public DuplicateGraphPathExceptionDTO(String type, String localizedMessage, String developerMessage)
  {
    super(type, localizedMessage, developerMessage);
  }
}
