package com.runwaysdk;

import java.util.Locale;
import java.util.ResourceBundle;

import com.runwaysdk.ConfigurationException;
import com.runwaysdk.ExceptionMessageLocalizer;

public class ClientExceptionMessageLocalizer extends ExceptionMessageLocalizer
{
  private static final String BUNDLE = "clientExceptions";

  /**
   * Fetches the parameterized, localized error message template for the given exception.
   * The variable String arguments represent the parameters in the template string. For
   * example, given the template "The {0} in the {1}." and arguments "cat" and "hat", the
   * final String will be "The cat in the hat."
   *
   * @param locale
   *          The desired locale of the message
   * @param key
   *          The name of the Exception whose message is being retrieved
   * @param params
   *          The array of parameters to plug into the template string
   */
  protected static String getMessage(Locale locale, String key, String... params)
  {
    String hashkey = BUNDLE;

    if (locale != null)
    {
      hashkey += "-" + locale.toString();

      if (!props.containsKey(hashkey))
      {
        props.put(hashkey, ResourceBundle.getBundle(BUNDLE, locale));
      }
    }
    else if (!props.containsKey(hashkey))
    {
      props.put(hashkey, ResourceBundle.getBundle(BUNDLE));
    }
    
    String template = props.get(hashkey).getString(key);

    return parseMessage(template, params);
  }

  /**
   * Gets the localized message, which indicates an unspecified error.
   *
   * @param locale
   *          The desired locale
   *
   * @return The localized error message
   */
  public static String unspecifiedException(Locale locale)
  {
    return getMessage(locale, "UnspecifiedException");
  }

  /**
   * Gets the localized message, which indicates an
   * error with a ClientRequest.
   *
   * @param locale
   *          The desired locale
   *
   * @return The localized error message
   */
  public static String clientRequestException(Locale locale)
  {
    // This is not a cut and paste error.  End users will not understand clientRequest errors.
    return getMessage(locale, "UnspecifiedException");
  }

  /**
   * Gets the localized message, which indicates an error with
   * conversions (used with Web Services to translate between documents
   * and objects).
   *
   * @param locale
   *          The desired locale
   *
   * @return The localized error message
   */
  public static String conversionException(Locale locale)
  {
    return getMessage(locale, "UnspecifiedException");
  }

  /**
   * Gets the localized message, which indicates an error
   * thrown from the server side.
   *
   * @param locale
   *          The desired locale
   *
   * @return The localized error message
   */
  public static String serverSideException(Locale locale)
  {
    return getMessage(locale, "UnspecifiedException");
  }

  /**
   * Gets the localized message, which indicates an error
   * thrown from the RMI services.
   */
  public static String rmiClientRequestException(Locale locale)
  {
    return getMessage(locale, "UnspecifiedException");
  }

  /**
   * Gets the localized message, which indicates an error
   * thrown from web services.
   */
  public static String webServiceClientRequestException(Locale locale)
  {
    return getMessage(locale, "UnspecifiedException");
  }


  /**
   * Gets the localized {@link ConfigurationException} message.
   *
   * @param locale
   *          The desired locale
   * @return The localized error message
   */
  public static String configurationException(Locale locale)
  {
    return getMessage(locale, "ConfigurationException");
  }

  /**
   * Gets the localized message for an error thrown
   * when an admin tries to request a non-unique type name to view.
   *
   * @param locale
   * @return
   */
  public static String shortHandTypeDuplicateException(Locale locale, String typeName)
  {
    return getMessage(locale, "shortHandTypeDuplicateException", typeName);
  }

  /**
   * Gets the localized message for an error thrown
   * when an admin tries to request an invalid type to view.
   *
   * @param locale
   * @return
   */
  public static String shortHandTypeInvalidException(Locale locale, String typeName)
  {
    return getMessage(locale, "shortHandTypeInvalidException", typeName);
  }

  public static String unknownServletException(Locale locale, String controllerName)
  {
    return getMessage(locale, "UnknownServletException", controllerName);
  }

  public static String illegalURIMethodException(Locale locale, String uri)
  {
    return getMessage(locale, "IllegalURIMethodException", uri);
  }

  public static String nullClientRequestException(Locale locale)
  {
    return getMessage(locale, "NullClientRequestException");
  }

  public static String undefinedControllerAction(Locale locale, String action)
  {
    return getMessage(locale, "UndefinedControllerAction");
  }

  /**
   * Gets the localized message for an error thrown when an accessor method is called when the
   * isReadable value returns false.
   *
   * @param locale
   * @param attributeDisplayLabel
   * @param classDisplayLabel
   *
   * @return localized message for an error thrown when an accessor method is called when the
   * isReadable value returns false.
   */
  public static String clientReadAttributePermissionException(Locale locale, String attributeDisplayLabel, String classDisplayLabel)
  {
    return getMessage(locale, "ClientReadAttributePermissionException", attributeDisplayLabel, classDisplayLabel);
  }
}