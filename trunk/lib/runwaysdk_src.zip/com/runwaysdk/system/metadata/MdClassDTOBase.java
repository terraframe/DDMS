package com.runwaysdk.system.metadata;

@com.runwaysdk.business.ClassSignature(hash = -642038472)
public abstract class MdClassDTOBase extends com.runwaysdk.system.metadata.MdTypeDTO
{
  public final static String CLASS = "com.runwaysdk.system.metadata.MdClass";
  private static final long serialVersionUID = -642038472;
  
  protected MdClassDTOBase(com.runwaysdk.constants.ClientRequestIF clientRequest)
  {
    super(clientRequest);
  }
  
  /**
  * Copy Constructor: Duplicates the values and attributes of the given BusinessDTO into a new DTO.
  * 
  * @param businessDTO The BusinessDTO to duplicate
  * @param clientRequest The clientRequest this DTO should use to communicate with the server.
  */
  protected MdClassDTOBase(com.runwaysdk.business.BusinessDTO businessDTO, com.runwaysdk.constants.ClientRequestIF clientRequest)
  {
    super(businessDTO, clientRequest);
  }
  
  protected java.lang.String getDeclaredType()
  {
    return CLASS;
  }
  
  public static java.lang.String PUBLISH = "publish";
  public static java.lang.String STUBCLASS = "stubClass";
  public static java.lang.String STUBDTOCLASS = "stubDTOClass";
  public static java.lang.String STUBDTOSOURCE = "stubDTOSource";
  public static java.lang.String STUBSOURCE = "stubSource";
  public Boolean getPublish()
  {
    return com.runwaysdk.constants.MdAttributeBooleanUtil.getTypeSafeValue(getValue(PUBLISH));
  }
  
  public void setPublish(Boolean value)
  {
    if(value == null)
    {
      setValue(PUBLISH, "");
    }
    else
    {
      setValue(PUBLISH, java.lang.Boolean.toString(value));
    }
  }
  
  public boolean isPublishWritable()
  {
    return isWritable(PUBLISH);
  }
  
  public boolean isPublishReadable()
  {
    return isReadable(PUBLISH);
  }
  
  public boolean isPublishModified()
  {
    return isModified(PUBLISH);
  }
  
  public final com.runwaysdk.transport.metadata.AttributeBooleanMdDTO getPublishMd()
  {
    return (com.runwaysdk.transport.metadata.AttributeBooleanMdDTO) getAttributeDTO(PUBLISH).getAttributeMdDTO();
  }
  
  public byte[] getStubClass()
  {
    return super.getBlob(STUBCLASS);
  }
  
  public boolean isStubClassWritable()
  {
    return isWritable(STUBCLASS);
  }
  
  public boolean isStubClassReadable()
  {
    return isReadable(STUBCLASS);
  }
  
  public boolean isStubClassModified()
  {
    return isModified(STUBCLASS);
  }
  
  public final com.runwaysdk.transport.metadata.AttributeBlobMdDTO getStubClassMd()
  {
    return (com.runwaysdk.transport.metadata.AttributeBlobMdDTO) getAttributeDTO(STUBCLASS).getAttributeMdDTO();
  }
  
  public byte[] getStubDTOClass()
  {
    return super.getBlob(STUBDTOCLASS);
  }
  
  public boolean isStubDTOClassWritable()
  {
    return isWritable(STUBDTOCLASS);
  }
  
  public boolean isStubDTOClassReadable()
  {
    return isReadable(STUBDTOCLASS);
  }
  
  public boolean isStubDTOClassModified()
  {
    return isModified(STUBDTOCLASS);
  }
  
  public final com.runwaysdk.transport.metadata.AttributeBlobMdDTO getStubDTOClassMd()
  {
    return (com.runwaysdk.transport.metadata.AttributeBlobMdDTO) getAttributeDTO(STUBDTOCLASS).getAttributeMdDTO();
  }
  
  public String getStubDTOSource()
  {
    return getValue(STUBDTOSOURCE);
  }
  
  public void setStubDTOSource(String value)
  {
    if(value == null)
    {
      setValue(STUBDTOSOURCE, "");
    }
    else
    {
      setValue(STUBDTOSOURCE, value);
    }
  }
  
  public boolean isStubDTOSourceWritable()
  {
    return isWritable(STUBDTOSOURCE);
  }
  
  public boolean isStubDTOSourceReadable()
  {
    return isReadable(STUBDTOSOURCE);
  }
  
  public boolean isStubDTOSourceModified()
  {
    return isModified(STUBDTOSOURCE);
  }
  
  public final com.runwaysdk.transport.metadata.AttributeTextMdDTO getStubDTOSourceMd()
  {
    return (com.runwaysdk.transport.metadata.AttributeTextMdDTO) getAttributeDTO(STUBDTOSOURCE).getAttributeMdDTO();
  }
  
  public String getStubSource()
  {
    return getValue(STUBSOURCE);
  }
  
  public void setStubSource(String value)
  {
    if(value == null)
    {
      setValue(STUBSOURCE, "");
    }
    else
    {
      setValue(STUBSOURCE, value);
    }
  }
  
  public boolean isStubSourceWritable()
  {
    return isWritable(STUBSOURCE);
  }
  
  public boolean isStubSourceReadable()
  {
    return isReadable(STUBSOURCE);
  }
  
  public boolean isStubSourceModified()
  {
    return isModified(STUBSOURCE);
  }
  
  public final com.runwaysdk.transport.metadata.AttributeTextMdDTO getStubSourceMd()
  {
    return (com.runwaysdk.transport.metadata.AttributeTextMdDTO) getAttributeDTO(STUBSOURCE).getAttributeMdDTO();
  }
  
  @SuppressWarnings("unchecked")
  public java.util.List<? extends com.runwaysdk.system.metadata.MdAttributeDTO> getAllAttribute()
  {
    return (java.util.List<? extends com.runwaysdk.system.metadata.MdAttributeDTO>) getRequest().getChildren(this.getId(), com.runwaysdk.system.metadata.ClassAttributeDTO.CLASS);
  }
  
  @SuppressWarnings("unchecked")
  public static java.util.List<? extends com.runwaysdk.system.metadata.MdAttributeDTO> getAllAttribute(com.runwaysdk.constants.ClientRequestIF clientRequestIF, String id)
  {
    return (java.util.List<? extends com.runwaysdk.system.metadata.MdAttributeDTO>) clientRequestIF.getChildren(id, com.runwaysdk.system.metadata.ClassAttributeDTO.CLASS);
  }
  
  @SuppressWarnings("unchecked")
  public java.util.List<? extends com.runwaysdk.system.metadata.ClassAttributeDTO> getAllAttributeRelationships()
  {
    return (java.util.List<? extends com.runwaysdk.system.metadata.ClassAttributeDTO>) getRequest().getChildRelationships(this.getId(), com.runwaysdk.system.metadata.ClassAttributeDTO.CLASS);
  }
  
  @SuppressWarnings("unchecked")
  public static java.util.List<? extends com.runwaysdk.system.metadata.ClassAttributeDTO> getAllAttributeRelationships(com.runwaysdk.constants.ClientRequestIF clientRequestIF, String id)
  {
    return (java.util.List<? extends com.runwaysdk.system.metadata.ClassAttributeDTO>) clientRequestIF.getChildRelationships(id, com.runwaysdk.system.metadata.ClassAttributeDTO.CLASS);
  }
  
  public com.runwaysdk.system.metadata.ClassAttributeDTO addAttribute(com.runwaysdk.system.metadata.MdAttributeDTO child)
  {
    return (com.runwaysdk.system.metadata.ClassAttributeDTO) getRequest().addChild(this.getId(), child.getId(), com.runwaysdk.system.metadata.ClassAttributeDTO.CLASS);
  }
  
  public static com.runwaysdk.system.metadata.ClassAttributeDTO addAttribute(com.runwaysdk.constants.ClientRequestIF clientRequestIF, String id, com.runwaysdk.system.metadata.MdAttributeDTO child)
  {
    return (com.runwaysdk.system.metadata.ClassAttributeDTO) clientRequestIF.addChild(id, child.getId(), com.runwaysdk.system.metadata.ClassAttributeDTO.CLASS);
  }
  
  public void removeAttribute(com.runwaysdk.system.metadata.ClassAttributeDTO relationship)
  {
    getRequest().deleteChild(relationship.getId());
  }
  
  public static void removeAttribute(com.runwaysdk.constants.ClientRequestIF clientRequestIF, com.runwaysdk.system.metadata.ClassAttributeDTO relationship)
  {
    clientRequestIF.deleteChild(relationship.getId());
  }
  
  public void removeAllAttribute()
  {
    getRequest().deleteChildren(this.getId(), com.runwaysdk.system.metadata.ClassAttributeDTO.CLASS);
  }
  
  public static void removeAllAttribute(com.runwaysdk.constants.ClientRequestIF clientRequestIF, String id)
  {
    clientRequestIF.deleteChildren(id, com.runwaysdk.system.metadata.ClassAttributeDTO.CLASS);
  }
  
  @SuppressWarnings("unchecked")
  public java.util.List<? extends com.runwaysdk.system.metadata.MdAttributeConcreteDTO> getAllConcreteAttribute()
  {
    return (java.util.List<? extends com.runwaysdk.system.metadata.MdAttributeConcreteDTO>) getRequest().getChildren(this.getId(), com.runwaysdk.system.metadata.ClassAttributeConcreteDTO.CLASS);
  }
  
  @SuppressWarnings("unchecked")
  public static java.util.List<? extends com.runwaysdk.system.metadata.MdAttributeConcreteDTO> getAllConcreteAttribute(com.runwaysdk.constants.ClientRequestIF clientRequestIF, String id)
  {
    return (java.util.List<? extends com.runwaysdk.system.metadata.MdAttributeConcreteDTO>) clientRequestIF.getChildren(id, com.runwaysdk.system.metadata.ClassAttributeConcreteDTO.CLASS);
  }
  
  @SuppressWarnings("unchecked")
  public java.util.List<? extends com.runwaysdk.system.metadata.ClassAttributeConcreteDTO> getAllConcreteAttributeRelationships()
  {
    return (java.util.List<? extends com.runwaysdk.system.metadata.ClassAttributeConcreteDTO>) getRequest().getChildRelationships(this.getId(), com.runwaysdk.system.metadata.ClassAttributeConcreteDTO.CLASS);
  }
  
  @SuppressWarnings("unchecked")
  public static java.util.List<? extends com.runwaysdk.system.metadata.ClassAttributeConcreteDTO> getAllConcreteAttributeRelationships(com.runwaysdk.constants.ClientRequestIF clientRequestIF, String id)
  {
    return (java.util.List<? extends com.runwaysdk.system.metadata.ClassAttributeConcreteDTO>) clientRequestIF.getChildRelationships(id, com.runwaysdk.system.metadata.ClassAttributeConcreteDTO.CLASS);
  }
  
  public com.runwaysdk.system.metadata.ClassAttributeConcreteDTO addConcreteAttribute(com.runwaysdk.system.metadata.MdAttributeConcreteDTO child)
  {
    return (com.runwaysdk.system.metadata.ClassAttributeConcreteDTO) getRequest().addChild(this.getId(), child.getId(), com.runwaysdk.system.metadata.ClassAttributeConcreteDTO.CLASS);
  }
  
  public static com.runwaysdk.system.metadata.ClassAttributeConcreteDTO addConcreteAttribute(com.runwaysdk.constants.ClientRequestIF clientRequestIF, String id, com.runwaysdk.system.metadata.MdAttributeConcreteDTO child)
  {
    return (com.runwaysdk.system.metadata.ClassAttributeConcreteDTO) clientRequestIF.addChild(id, child.getId(), com.runwaysdk.system.metadata.ClassAttributeConcreteDTO.CLASS);
  }
  
  public void removeConcreteAttribute(com.runwaysdk.system.metadata.ClassAttributeConcreteDTO relationship)
  {
    getRequest().deleteChild(relationship.getId());
  }
  
  public static void removeConcreteAttribute(com.runwaysdk.constants.ClientRequestIF clientRequestIF, com.runwaysdk.system.metadata.ClassAttributeConcreteDTO relationship)
  {
    clientRequestIF.deleteChild(relationship.getId());
  }
  
  public void removeAllConcreteAttribute()
  {
    getRequest().deleteChildren(this.getId(), com.runwaysdk.system.metadata.ClassAttributeConcreteDTO.CLASS);
  }
  
  public static void removeAllConcreteAttribute(com.runwaysdk.constants.ClientRequestIF clientRequestIF, String id)
  {
    clientRequestIF.deleteChildren(id, com.runwaysdk.system.metadata.ClassAttributeConcreteDTO.CLASS);
  }
  
  @SuppressWarnings("unchecked")
  public java.util.List<? extends com.runwaysdk.system.metadata.MdClassDTO> getAllSubEntity()
  {
    return (java.util.List<? extends com.runwaysdk.system.metadata.MdClassDTO>) getRequest().getChildren(this.getId(), com.runwaysdk.system.metadata.ClassInheritanceDTO.CLASS);
  }
  
  @SuppressWarnings("unchecked")
  public static java.util.List<? extends com.runwaysdk.system.metadata.MdClassDTO> getAllSubEntity(com.runwaysdk.constants.ClientRequestIF clientRequestIF, String id)
  {
    return (java.util.List<? extends com.runwaysdk.system.metadata.MdClassDTO>) clientRequestIF.getChildren(id, com.runwaysdk.system.metadata.ClassInheritanceDTO.CLASS);
  }
  
  @SuppressWarnings("unchecked")
  public java.util.List<? extends com.runwaysdk.system.metadata.ClassInheritanceDTO> getAllSubEntityRelationships()
  {
    return (java.util.List<? extends com.runwaysdk.system.metadata.ClassInheritanceDTO>) getRequest().getChildRelationships(this.getId(), com.runwaysdk.system.metadata.ClassInheritanceDTO.CLASS);
  }
  
  @SuppressWarnings("unchecked")
  public static java.util.List<? extends com.runwaysdk.system.metadata.ClassInheritanceDTO> getAllSubEntityRelationships(com.runwaysdk.constants.ClientRequestIF clientRequestIF, String id)
  {
    return (java.util.List<? extends com.runwaysdk.system.metadata.ClassInheritanceDTO>) clientRequestIF.getChildRelationships(id, com.runwaysdk.system.metadata.ClassInheritanceDTO.CLASS);
  }
  
  public com.runwaysdk.system.metadata.ClassInheritanceDTO addSubEntity(com.runwaysdk.system.metadata.MdClassDTO child)
  {
    return (com.runwaysdk.system.metadata.ClassInheritanceDTO) getRequest().addChild(this.getId(), child.getId(), com.runwaysdk.system.metadata.ClassInheritanceDTO.CLASS);
  }
  
  public static com.runwaysdk.system.metadata.ClassInheritanceDTO addSubEntity(com.runwaysdk.constants.ClientRequestIF clientRequestIF, String id, com.runwaysdk.system.metadata.MdClassDTO child)
  {
    return (com.runwaysdk.system.metadata.ClassInheritanceDTO) clientRequestIF.addChild(id, child.getId(), com.runwaysdk.system.metadata.ClassInheritanceDTO.CLASS);
  }
  
  public void removeSubEntity(com.runwaysdk.system.metadata.ClassInheritanceDTO relationship)
  {
    getRequest().deleteChild(relationship.getId());
  }
  
  public static void removeSubEntity(com.runwaysdk.constants.ClientRequestIF clientRequestIF, com.runwaysdk.system.metadata.ClassInheritanceDTO relationship)
  {
    clientRequestIF.deleteChild(relationship.getId());
  }
  
  public void removeAllSubEntity()
  {
    getRequest().deleteChildren(this.getId(), com.runwaysdk.system.metadata.ClassInheritanceDTO.CLASS);
  }
  
  public static void removeAllSubEntity(com.runwaysdk.constants.ClientRequestIF clientRequestIF, String id)
  {
    clientRequestIF.deleteChildren(id, com.runwaysdk.system.metadata.ClassInheritanceDTO.CLASS);
  }
  
  @SuppressWarnings("unchecked")
  public java.util.List<? extends com.runwaysdk.system.metadata.MdClassDTO> getAllInheritsFromEntity()
  {
    return (java.util.List<? extends com.runwaysdk.system.metadata.MdClassDTO>) getRequest().getParents(this.getId(), com.runwaysdk.system.metadata.ClassInheritanceDTO.CLASS);
  }
  
  @SuppressWarnings("unchecked")
  public static java.util.List<? extends com.runwaysdk.system.metadata.MdClassDTO> getAllInheritsFromEntity(com.runwaysdk.constants.ClientRequestIF clientRequestIF, String id)
  {
    return (java.util.List<? extends com.runwaysdk.system.metadata.MdClassDTO>) clientRequestIF.getParents(id, com.runwaysdk.system.metadata.ClassInheritanceDTO.CLASS);
  }
  
  @SuppressWarnings("unchecked")
  public java.util.List<? extends com.runwaysdk.system.metadata.ClassInheritanceDTO> getAllInheritsFromEntityRelationships()
  {
    return (java.util.List<? extends com.runwaysdk.system.metadata.ClassInheritanceDTO>) getRequest().getParentRelationships(this.getId(), com.runwaysdk.system.metadata.ClassInheritanceDTO.CLASS);
  }
  
  @SuppressWarnings("unchecked")
  public static java.util.List<? extends com.runwaysdk.system.metadata.ClassInheritanceDTO> getAllInheritsFromEntityRelationships(com.runwaysdk.constants.ClientRequestIF clientRequestIF, String id)
  {
    return (java.util.List<? extends com.runwaysdk.system.metadata.ClassInheritanceDTO>) clientRequestIF.getParentRelationships(id, com.runwaysdk.system.metadata.ClassInheritanceDTO.CLASS);
  }
  
  public com.runwaysdk.system.metadata.ClassInheritanceDTO addInheritsFromEntity(com.runwaysdk.system.metadata.MdClassDTO parent)
  {
    return (com.runwaysdk.system.metadata.ClassInheritanceDTO) getRequest().addParent(parent.getId(), this.getId(), com.runwaysdk.system.metadata.ClassInheritanceDTO.CLASS);
  }
  
  public static com.runwaysdk.system.metadata.ClassInheritanceDTO addInheritsFromEntity(com.runwaysdk.constants.ClientRequestIF clientRequestIF, String id, com.runwaysdk.system.metadata.MdClassDTO parent)
  {
    return (com.runwaysdk.system.metadata.ClassInheritanceDTO) clientRequestIF.addParent(parent.getId(), id, com.runwaysdk.system.metadata.ClassInheritanceDTO.CLASS);
  }
  
  public void removeInheritsFromEntity(com.runwaysdk.system.metadata.ClassInheritanceDTO relationship)
  {
    getRequest().deleteParent(relationship.getId());
  }
  
  public static void removeInheritsFromEntity(com.runwaysdk.constants.ClientRequestIF clientRequestIF, com.runwaysdk.system.metadata.ClassInheritanceDTO relationship)
  {
    clientRequestIF.deleteParent(relationship.getId());
  }
  
  public void removeAllInheritsFromEntity()
  {
    getRequest().deleteParents(this.getId(), com.runwaysdk.system.metadata.ClassInheritanceDTO.CLASS);
  }
  
  public static void removeAllInheritsFromEntity(com.runwaysdk.constants.ClientRequestIF clientRequestIF, String id)
  {
    clientRequestIF.deleteParents(id, com.runwaysdk.system.metadata.ClassInheritanceDTO.CLASS);
  }
  
  public static com.runwaysdk.system.metadata.MdClassDTO get(com.runwaysdk.constants.ClientRequestIF clientRequest, String id)
  {
    com.runwaysdk.business.EntityDTO dto = (com.runwaysdk.business.EntityDTO)clientRequest.get(id);
    
    return (com.runwaysdk.system.metadata.MdClassDTO) dto;
  }
  
  public void apply()
  {
    if(isNewInstance())
    {
      getRequest().createBusiness(this);
    }
    else
    {
      getRequest().update(this);
    }
  }
  public void delete()
  {
    getRequest().delete(this.getId());
  }
  
  public static com.runwaysdk.system.metadata.MdClassQueryDTO getAllInstances(com.runwaysdk.constants.ClientRequestIF clientRequest, String sortAttribute, Boolean ascending, Integer pageSize, Integer pageNumber)
  {
    return (com.runwaysdk.system.metadata.MdClassQueryDTO) clientRequest.getAllInstances(com.runwaysdk.system.metadata.MdClassDTO.CLASS, sortAttribute, ascending, pageSize, pageNumber);
  }
  
  public void lock()
  {
    getRequest().lock(this);
  }
  
  public static com.runwaysdk.system.metadata.MdClassDTO lock(com.runwaysdk.constants.ClientRequestIF clientRequest, java.lang.String id)
  {
    String[] _declaredTypes = new String[]{"java.lang.String"};
    Object[] _parameters = new Object[]{id};
    com.runwaysdk.business.MethodMetaData _metadata = new com.runwaysdk.business.MethodMetaData(com.runwaysdk.system.metadata.MdClassDTO.CLASS, "lock", _declaredTypes);
    return (com.runwaysdk.system.metadata.MdClassDTO) clientRequest.invokeMethod(_metadata, null, _parameters);
  }
  
  public void unlock()
  {
    getRequest().unlock(this);
  }
  
  public static com.runwaysdk.system.metadata.MdClassDTO unlock(com.runwaysdk.constants.ClientRequestIF clientRequest, java.lang.String id)
  {
    String[] _declaredTypes = new String[]{"java.lang.String"};
    Object[] _parameters = new Object[]{id};
    com.runwaysdk.business.MethodMetaData _metadata = new com.runwaysdk.business.MethodMetaData(com.runwaysdk.system.metadata.MdClassDTO.CLASS, "unlock", _declaredTypes);
    return (com.runwaysdk.system.metadata.MdClassDTO) clientRequest.invokeMethod(_metadata, null, _parameters);
  }
  
}
