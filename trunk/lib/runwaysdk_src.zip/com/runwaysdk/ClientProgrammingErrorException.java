package com.runwaysdk;

import com.runwaysdk.ApplicationException;



public class ClientProgrammingErrorException extends ApplicationException
{
  /**
   * 
   */
  private static final long serialVersionUID = 6617347337899082889L;

  // Heads up: write error to a client side log file.
  /**
   * Constructs a new ClientProgrammingErrorException with the specified developer message.
   * 
   * @param devMessage
   *          The non-localized developer error message. Contains specific data
   *          access layer information useful for application debugging. The
   *          developer message is saved for later retrieval by the
   *          {@link #getMessage()} method.
   */
  public ClientProgrammingErrorException(String devMessage)
  {
    super(devMessage);
  }

  /**
   * Constructs a new ClientProgrammingErrorException with the specified developer message
   * and cause.
   * <p>
   * Note that the detail message associated with <code>cause</code> is <i>not</i>
   * automatically incorporated in this ClientProgrammingErrorException's detail message.
   * 
   * @param devMessage
   *          The non-localized developer error message. Contains specific data
   *          access layer information useful for application debugging. The
   *          developer message is saved for later retrieval by the
   *          {@link #getMessage()} method.
   * @param cause
   *          the cause (which is saved for later retrieval by the
   *          {@link #getCause()} method). (A <tt>null</tt> value is
   *          permitted, and indicates that the cause is nonexistent or
   *          unknown.)
   */
  public ClientProgrammingErrorException(String devMessage, Throwable cause)
  {
    super(devMessage, cause);
  }

  /**
   * Constructs a new ClientProgrammingErrorException with the specified cause and a
   * developer message taken from the cause. This constructor is useful if the
   * ClientProgrammingErrorException is a wrapper for another throwable.
   * 
   * @param cause
   *          the cause (which is saved for later retrieval by the
   *          {@link #getCause()} method). (A <tt>null</tt> value is
   *          permitted, and indicates that the cause is nonexistent or
   *          unknown.)
   */
  public ClientProgrammingErrorException(Throwable cause)
  {
    super(cause);
  }  
}
