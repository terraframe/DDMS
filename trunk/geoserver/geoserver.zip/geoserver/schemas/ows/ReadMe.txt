2007-04-03  Arliss Whiteside

	* v1.1.0: OWS Common specification has been updated to version 1.1.0
	  (OGC 06-121r3). These very small changes are taken from corrigendum
	  (OGC 07-016) which corrects the schemaLocation references in
	  <import> declarations for the namespace
	  http://www.w3.org/1999/xlink, in the OWS Common 1.1 XML Schema.
	  These schemaLocation references are changed to relatively reference
	  the old schema location at
	  http://www.opengis.net/xlink/1.0.0/xlinks.xsd .  

	* Note: check each OGC numbered document for detailed changes.

2005-11-22  Arliss Whiteside

	* v1.0.0, v0.4.0, v0.3.2, v0.3.1, v0.3.0: All five of these sets of
	  XML Schema Documents have been edited to reflect the corrigenda to
	  all those OGC documents which are based on the change requests: 
	  OGC 05-068r1 "Store xlinks.xsd file at a fixed location"
	  OGC 05-081r2 "Change to use relative paths"

	* v1.0.0: The 1.0.0 version are the XML Schema Documents for OGC
	  document 05-008, approved as an Implementation Specification in May
	  2005.

	* v0.4.0: The 0.4.0 version are the XML Schema Documents for OGC
	  document 04-016r5.

	* v0.3.2: The 0.3.2 version are the XML Schema Documents after
	  correcting one small incorrect difference from OGC document
	  04-016r3.

	* v0.3.1: The 0.3.1 version are the XML Schema Documents attached to
	  OGC document 04-016r3, containing that editing of document 04-016r2.
	  This Recommendation Paper is available to the public at
	  http://portal.opengis.org/files/?artifact_id=6324.

	* v0.3.0: OWS Common set of XML Schema Documents from OGC document
	  04-016r2 approved as Recommendation Paper in the April 2004 OGC 
	  meetings.

