SLD quick note
---------------

These files are not directly read by GeoServer when the maps are rendered. There are here for when you configure GeoServer to give it new Styles. GeoServer will copy them from this location to its data/styles directory.