This is EditArea 0.6.7, grabbed from http://www.cdolivet.net/index.php?page=editArea.
If you upgrade it, update this file too with the new version number.